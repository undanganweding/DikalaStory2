import { db } from './db';
import { aiBudgetRegistry } from './ai_infrastructure/ai_budget_registry';
import { executionPreflight } from './ai_infrastructure/execution_preflight';
import { modelRouter } from './model_router';
import { DEFAULT_TASK_PROFILES } from './adaptive_router';
import { taskRouter } from './ai_infrastructure/task_router';
import { getTaskByStageCode } from './ai_infrastructure/task_registry';
import { runStage1StoryUnderstanding } from './stages/stage1_story_understanding';
import { runStage2CharacterDetection } from './stages/stage2_character_detection';
import { runStage3LocationObjectDetection } from './stages/stage3_location_object_detection';
import { runStage4NarrativeStructure } from './stages/stage4_narrative_structure';
import {
  runStage5SceneBreakdownAttempt,
  validateSceneDurations,
  validateSceneAssetNames,
  validateSceneSemanticPayload,
  DetectedScene,
  allocateAndNormalizeSceneDurations,
} from './stages/stage5_scene_breakdown';
import {
  runStage6ShotBreakdownAttempt,
  validateShotBreakdown,
  validateShotDurationTotal,
  DetectedShot,
} from './stages/stage6_shot_breakdown';
import { runStage7MasterFrameAndImagePrompt } from './stages/stage7_master_frame';
import { runStage8VideoPrompt } from './stages/stage8_video_prompt';
import { classifyError } from './llm_provider';
import {
  buildContinuitySnapshot,
  buildContinuityInstruction,
  validateSceneContinuity,
  applyContinuityCorrectionToPrompt,
} from './continuity_engine';
import {
  synthesizeStoryArchitectureForLegacyProject,
  deriveBeatsForScene,
  CINEMATIC_GRAMMAR_GUIDELINES,
} from './story_architecture';
import { buildFullScenePrompt } from './full_scene_prompt';
import { ensureGroundingForProject, GROUNDING_VERSION, buildGroundingContextPackage, validateGroundingContext } from './grounding_engine';
import { executeResearchPackage, ResearchEngine } from './research_engine';
import { resolveResearchPackage } from './claim_resolution_engine';
import { extractClaimsFromEvidence } from './claim_extraction_engine';
import { assertStageConsistency, createGroundingState, evaluateStageOutput } from './consistency_engine';
import { createContinuityState, updateContinuityState } from './continuity_engine';
import {
  assertSceneAssetCoverage,
  createSceneAssetCoverageReport,
  validateMasterFrameCoverage,
  validatePromptCoverage,
  validateVideoPromptCoverage,
} from './scene_asset_integrity_engine';
import { assertFinalizationGate, evaluateFinalizationGate } from './finalization_gate';
import {
  Project,
  ProjectFoundation,
  Scene,
  Shot,
  StageCode,
  StageScope,
  StageExecutionTelemetry,
  ErrorClassification,
  ContinuityScope,
  ScenePipelineBlocker,
  SceneAssetCoverageReport,
  FinalizationBlocker,
  ContinuityViolation,
  ContinuitySnapshot,
  NarrativeMode,
} from '../src/types';

export interface GenerationRunContext {
  runId: string;
  projectId: string;
  startedAt: string;
  concurrency?: number;
}

export interface OrchestratorRunOptions {
  projectId: string;
  onProgress?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void;
  runContext?: GenerationRunContext;
  /** Optional explicit concurrency override. Cascade: sceneConcurrency > runContext.concurrency > SCENE_GENERATION_CONCURRENCY env > 2 */
  sceneConcurrency?: number;
}

// Per-project in-flight init lock. Prevents runProjectInitialization from being
// executed concurrently for the same projectId (e.g. runOrchestratedPipeline
// running init, then generateAllScenes re-entering init while foundation is
// still marked 'initializing'). A duplicate concurrent init burns Gemini quota
// (HTTP 429 RESOURCE_EXHAUSTED) twice as fast and trips the retry/backoff loop
// that surfaces as a frozen pipeline at a later stage.
const initializationInFlight = new Map<string, Promise<{ success: boolean; error?: string }>>();
const initializationListeners = new Map<
  string,
  Set<(stage: number, stageName: string, message: string, level?: 'info' | 'success' | 'warn' | 'error') => void>
>();
const orchestratedPipelineInFlight = new Map<string, Promise<{ success: boolean; error?: string; runId?: string }>>();
const orchestratedPipelineListeners = new Map<
  string,
  Set<(stage: number, stageName: string, message: string, level?: 'info' | 'success' | 'warn' | 'error') => void>
>();
const generateAllScenesInFlight = new Map<string, Promise<{ success: boolean; totalScenes: number; readyScenes: number; failedScenes: number }>>();
const singleScenePipelineInFlight = new Map<string, Promise<ScenePipelineResult>>();

export const stoppedProjects = new Set<string>();

export function isPipelineInFlight(projectId: string): boolean {
  return orchestratedPipelineInFlight.has(projectId) || initializationInFlight.has(projectId);
}

export function isInitializationInFlight(projectId: string): boolean {
  return initializationInFlight.has(projectId);
}

export class PipelineStoppedError extends Error {
  constructor() {
    super('Pipeline dihentikan oleh pengguna.');
    this.name = 'PipelineStoppedError';
  }
}

export function resetPipelineInFlightLocks(): void {
  initializationInFlight.clear();
  initializationListeners.clear();
  orchestratedPipelineInFlight.clear();
  orchestratedPipelineListeners.clear();
  generateAllScenesInFlight.clear();
  singleScenePipelineInFlight.clear();
  stoppedProjects.clear();
}

export async function resolveStageModel(
  stageCode: string,
  fallbackTask: import('./model_router').TaskType,
  fallbackComplexity: 'LOW' | 'MEDIUM' | 'HIGH' = 'MEDIUM'
): Promise<string> {
  const taskDef = getTaskByStageCode(stageCode);
  if (taskDef) {
    try {
      const plan = await taskRouter.resolveTaskExecutionPlan({
        taskId: taskDef.id,
        stageCode,
      });
      if (plan?.modelId) {
        return plan.modelId;
      }
    } catch {
      // fallback if task router fails
    }
  }

  const profile = DEFAULT_TASK_PROFILES[stageCode];
  if (profile?.default_model) {
    return profile.default_model;
  }
  const selectedModel = await modelRouter.getBestModel(fallbackTask, fallbackComplexity, 1);
  return selectedModel.modelId;
}

export function createGenerationRunContext(projectId: string, concurrency?: number): GenerationRunContext {
  return {
    runId: `run_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
    projectId,
    startedAt: new Date().toISOString(),
    concurrency,
  };
}

export interface FoundationVerificationResult {
  ready: boolean;
  missing: string[];
  completed: string[];
  foundationStatus: 'not_initialized' | 'initializing' | 'partial' | 'ready' | 'failed';
  foundation: ProjectFoundation | null;
  scenesCount: number;
}

export interface ProjectInitializationDependencies {
  researchEngine?: ResearchEngine;
  stage1Runner?: typeof runStage1StoryUnderstanding;
}

async function enforceStageConsistency(projectId: string, stage: string, output: unknown, state: ReturnType<typeof createGroundingState> | null): Promise<void> {
  if (!state) return;
  const report = evaluateStageOutput(stage, output, state);
  const project = await db.getProject(projectId);
  if (project) {
    const existing = (project.consistencyReports || []).filter((r) => r.stage !== stage);
    await db.saveProject({
      ...project,
      consistencyReports: [...existing, report],
    });
  }
  assertStageConsistency(report);
}

async function advanceContinuity(projectId: string, stage: string, scene: { id?: string; scene_number?: number; location_name?: string; character_names?: string[]; event?: string; era?: string; continuity_scope?: ContinuityScope }, output: unknown, state: ReturnType<typeof createContinuityState> | null, scope: ContinuityScope = 'within-scene', persist = true): Promise<ReturnType<typeof createContinuityState> | null> {
  if (!state) return null;
  const result = updateContinuityState(state, scene, output, undefined, scope);
  const project = await db.getProject(projectId);
  if (persist && project) await db.saveProject({ ...project, continuityState: result.state });
  const blocking = result.issues.find((issue) => issue.severity === 'BLOCKING');
  if (blocking) throw new Error(`CONTINUITY_BLOCKED ${stage}: ${blocking.message}`);
  return result.state;
}

export interface ScenePipelineResult {
  status: 'READY' | 'BLOCKED' | 'FAILED';
  success: boolean;
  sceneId: string;
  shots?: Shot[];
  blockers?: ScenePipelineBlocker[];
  continuityState?: ReturnType<typeof createContinuityState> | null;
  assetIntegrityReport?: SceneAssetCoverageReport;
  error?: string;
}

function knownBlocker(error: unknown, stage: string): ScenePipelineBlocker | null {
  const message = error instanceof Error ? error.message : String(error || '');
  const match = message.match(/^(CONTINUITY_BLOCKED|ASSET_INTEGRITY_BLOCKED|FINALIZATION_BLOCKED|CONSISTENCY_BLOCKED)\s*(.*)$/s);
  if (!match) return null;
  let payload: any = undefined;
  try { payload = match[2] ? JSON.parse(match[2]) : undefined; } catch { /* preserve the message when no JSON payload exists */ }
  const detail = payload?.blockerDetails?.[0]
    || payload?.blockers?.[0]
    || [...(payload?.characters || []), ...(payload?.locations || []), ...(payload?.objects || []), ...(payload?.videoPromptCoverage || [])].find((item) => item.status === 'BLOCKED' || item.status === 'MISMATCH');
  return {
    code: detail?.code || detail?.reason || match[1],
    severity: 'BLOCKING',
    message: detail?.message || message,
    stage,
    assetName: detail?.assetName,
    assetType: detail?.assetType,
  };
}

function isRetryableSceneError(error: unknown, classification: ErrorClassification): boolean {
  const message = error instanceof Error ? error.message.toLowerCase() : String(error || '').toLowerCase();
  return classification === 'schema_validation'
    || classification === 'network'
    || classification === 'rate_limit'
    || classification === 'quota_exceeded'
    || message.includes('empty response')
    || message.includes('empty output');
}

async function persistBlockedScene(sceneId: string, blocker: ScenePipelineBlocker): Promise<void> {
  await db.updateScene(sceneId, { status: 'blocked', pipeline_status: 'BLOCKED', blockers: [blocker] });
}

async function beginSceneExecution(sceneId: string): Promise<void> {
  await db.updateScene(sceneId, { status: 'processing', pipeline_status: undefined, blockers: [] });
}

async function persistReadyScene(sceneId: string, continuityStatus: 'passed' | 'warning' | 'continuity_failed', continuityViolations: ContinuityViolation[]): Promise<void> {
  await db.updateScene(sceneId, {
    status: continuityStatus === 'continuity_failed' ? 'blocked' : 'ready',
    pipeline_status: continuityStatus === 'continuity_failed' ? 'BLOCKED' : 'READY',
    blockers: continuityStatus === 'continuity_failed'
      ? continuityViolations.map((violation) => ({ code: 'CONTINUITY_BLOCKED', severity: 'BLOCKING', message: violation.message, stage: 'FINAL' }))
      : [],
  });
}

export function resolveCurrentSceneStatus(
  blockers: ScenePipelineBlocker[],
  failed: boolean
): ScenePipelineResult['status'] {
  if (blockers.length > 0) return 'BLOCKED';
  if (failed) return 'FAILED';
  return 'READY';
}

/**
 * Verifies if Project Foundation (S1-S5) is complete and valid.
 */
export async function verifyProjectFoundation(projectId: string): Promise<FoundationVerificationResult> {
  const missing: string[] = [];
  const completed: string[] = [];
  const foundation = await db.getProjectFoundation(projectId);
  const characters = await db.getCharacters(projectId);
  const locations = await db.getLocations(projectId);
  const scenes = await db.getScenes(projectId);

  if (foundation && foundation.genre && foundation.era) {
    completed.push('Story Foundation (S1)');
  } else {
    missing.push('Fondasi Cerita (S1)');
  }

  if (characters && characters.length > 0) {
    completed.push('Character Bible (S2)');
  } else {
    missing.push('Character Bible (S2)');
  }

  if (locations && locations.length > 0) {
    completed.push('Location Bible (S3)');
  } else {
    missing.push('Location Bible (S3)');
  }

  if (foundation?.narrative_beats && foundation.narrative_beats.beginning) {
    completed.push('Narrative Beats (S4)');
  } else {
    missing.push('Narrative Beats (S4)');
  }

  if (scenes && scenes.length > 0) {
    completed.push('Scene Breakdown (S5)');
  } else {
    missing.push('Scene Breakdown (S5)');
  }

  const isReady = missing.length === 0;
  const foundationStatus: FoundationVerificationResult['foundationStatus'] = isReady
    ? 'ready'
    : completed.length === 0
    ? 'not_initialized'
    : 'partial';

  // Update project foundation_status in db
  const project = await db.getProject(projectId);
  if (project) {
    const targetStatus = isReady ? 'ready' : completed.length === 0 ? 'not_initialized' : 'incomplete';
    if (project.foundation_status !== targetStatus && project.foundation_status !== 'initializing') {
      await db.saveProject({
        ...project,
        foundation_status: targetStatus,
      });
    }
  }

  return {
    ready: isReady,
    missing,
    completed,
    foundationStatus,
    foundation,
    scenesCount: scenes ? scenes.length : 0,
  };
}
/**
 * Helper to record telemetry event
 */
async function safeAddLog(projectId: string, payload: Parameters<typeof db.addLog>[1]): Promise<void> {
  try {
    await db.addLog(projectId, payload);
  } catch {
    // Observability failure must never impact pipeline execution.
  }
}

async function safeAddTelemetry(projectId: string, payload: Parameters<typeof db.addTelemetry>[1]): Promise<StageExecutionTelemetry | null> {
  try {
    return await db.addTelemetry(projectId, payload);
  } catch {
    // Observability failure must never impact pipeline execution.
    return null;
  }
}

async function recordTelemetry(
  projectId: string,
  telemetry: {
    stage?: number;
    stage_code?: StageCode;
    scope?: StageScope;
    scene_id?: string;
    shot_id?: string;
    attempt?: number;
    started_at?: string;
    completed_at?: string;
    duration_ms?: number;
    status?: 'started' | 'completed' | 'failed' | 'retrying' | 'blocked';
    error_type?: ErrorClassification;
    error_message?: string;
    run_id?: string;
    summary_type?: 'run' | 'scene' | 'stage';
    summary?: Record<string, any>;
  },
  runContext?: GenerationRunContext
): Promise<StageExecutionTelemetry> {
  const payload = {
    project_id: projectId,
    run_id: runContext?.runId ?? telemetry.run_id,
    ...telemetry,
  };
  return (await safeAddTelemetry(projectId, payload)) || ({ ...payload, project_id: projectId } as StageExecutionTelemetry);
}

async function safePersistRunSummary(
  projectId: string,
  runId: string | undefined,
  summary: Record<string, any>
): Promise<void> {
  try {
    await recordTelemetry(projectId, {
      stage: 0,
      stage_code: 'S1',
      scope: 'project',
      started_at: new Date().toISOString(),
      status: 'completed',
      summary_type: 'run',
      summary,
      run_id: runId,
    });
  } catch {
    // Observability must remain non-blocking.
  }
}

async function safePersistSceneSummary(
  projectId: string,
  runId: string | undefined,
  sceneId: string,
  sceneNumber: number,
  startedAtMs: number,
  finalStatus: ScenePipelineResult['status'],
  result: Partial<ScenePipelineResult> & { sceneId: string }
): Promise<void> {
  try {
    const completedAt = Date.now();
    const sceneDurationMs = Math.max(0, completedAt - startedAtMs);
    await recordTelemetry(projectId, {
      stage: 8,
      stage_code: 'S8',
      scope: 'scene',
      scene_id: sceneId,
      started_at: new Date(startedAtMs).toISOString(),
      completed_at: new Date(completedAt).toISOString(),
      duration_ms: sceneDurationMs,
      status: finalStatus === 'READY' ? 'completed' : finalStatus === 'BLOCKED' ? 'blocked' : 'failed',
      summary_type: 'scene',
      summary: {
        scene_id: sceneId,
        scene_number: sceneNumber,
        scene_status: finalStatus,
        success: result.success,
        ready: finalStatus === 'READY',
        blocked: finalStatus === 'BLOCKED',
        failed: finalStatus === 'FAILED',
        blockers: result.blockers?.length ?? 0,
        scene_duration_ms: sceneDurationMs,
        error: result.error,
      },
      run_id: runId,
    }, { runId } as GenerationRunContext);
  } catch {
    // Observability must remain non-blocking.
  }
}

/**
 * Runs Project Initialization Scope: Stages 1 to 5 ONLY.
 * Establishes project foundation, character bible, location bible, narrative beats, and scenes.
 */
export function runProjectInitialization(
  projectId: string,
  onProgress?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void,
  dependencies: ProjectInitializationDependencies = {}
): Promise<{ success: boolean; error?: string }> {
  // Concurrency-safe: a duplicate concurrent init (e.g. runOrchestratedPipeline
  // running init, then generateAllScenes re-entering while foundation is still
  // 'initializing') burns Gemini quota twice as fast and trips the 429
  // RESOURCE_EXHAUSTED retry/backoff loop that surfaces as a frozen pipeline.
  const existing = initializationInFlight.get(projectId);
  if (existing) {
    console.log(`[init] JOIN in-flight initialization project=${projectId}`);
    if (onProgress) {
      if (!initializationListeners.has(projectId)) {
        initializationListeners.set(projectId, new Set());
      }
      initializationListeners.get(projectId)!.add(onProgress);
    }
    return existing;
  }
  if (onProgress) {
    if (!initializationListeners.has(projectId)) {
      initializationListeners.set(projectId, new Set());
    }
    initializationListeners.get(projectId)!.add(onProgress);
  }
  const promise = runProjectInitializationImpl(projectId, onProgress, dependencies).finally(() => {
    initializationInFlight.delete(projectId);
    initializationListeners.delete(projectId);
  });
  initializationInFlight.set(projectId, promise);
  return promise;
}

async function runProjectInitializationImpl(
  projectId: string,
  onProgress?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void,
  dependencies: ProjectInitializationDependencies = {}
): Promise<{ success: boolean; error?: string }> {
  aiBudgetRegistry.initializeBudget(projectId, 50);
  try {
    return await aiBudgetRegistry.runWithProjectId(projectId, async () => {
      return await runProjectInitializationImplInner(projectId, onProgress, dependencies);
    });
  } finally {
    aiBudgetRegistry.cleanupBudget(projectId);
  }
}

async function runProjectInitializationImplInner(
  projectId: string,
  onProgress?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void,
  dependencies: ProjectInitializationDependencies = {}
): Promise<{ success: boolean; error?: string }> {
  const project = await db.getProject(projectId);
  if (!project) {
    throw new Error(`Project dengan ID ${projectId} tidak ditemukan.`);
  }

  const log = (
    stage: number,
    stageName: string,
    message: string,
    level: 'info' | 'success' | 'warn' | 'error' = 'info',
    stageCode?: StageCode,
    durationMs?: number,
    errorType?: ErrorClassification
  ) => {
    safeAddLog(projectId, {
      stage,
      stage_name: stageName,
      stage_code: stageCode || (`S${stage}` as StageCode),
      scope: 'project',
      message,
      level,
      duration_ms: durationMs,
      error_type: errorType,
    });
    const listeners = initializationListeners.get(projectId);
    if (listeners && listeners.size > 0) {
      for (const listener of listeners) {
        try {
          listener(stage, stageName, message, level);
        } catch {
          // Progress notification failure must be strictly non-fatal to backend pipeline
        }
      }
    } else if (onProgress) {
      try {
        onProgress(stage, stageName, message, level);
      } catch {
        // Non-fatal
      }
    }
  };

  try {
    if (stoppedProjects.has(projectId)) throw new PipelineStoppedError();
    // ==========================================
    // RESUME GUARD: skip stages whose outputs already persist
    // ==========================================
    const [existingFoundation, resumeCharacters, resumeLocations, resumeObjects, resumeScenes] = await Promise.all([
      db.getProjectFoundation(projectId),
      db.getCharacters(projectId),
      db.getLocations(projectId),
      db.getObjects(projectId),
      db.getScenes(projectId),
    ]);
    const resumeFoundation = existingFoundation && existingFoundation.genre && existingFoundation.era ? existingFoundation : null;
    const resumeNarrativeBeats = resumeFoundation?.narrative_beats?.beginning ? resumeFoundation.narrative_beats : null;
    const haveS1 = Boolean(resumeFoundation);
    const haveS2 = resumeCharacters.length > 0;
    const haveS3 = resumeLocations.length > 0;
    const haveS4 = Boolean(resumeNarrativeBeats);
    const haveS5 = resumeScenes.length > 0;

    const resumeFromStage = haveS5 ? 5 : haveS4 ? 5 : haveS3 ? 4 : haveS2 ? 3 : haveS1 ? 2 : 1;
    console.log(`[Pipeline Orchestrator] runProjectInitialization project=${projectId} status=${haveS5 ? 'READY' : haveS1 ? 'PARTIAL' : 'NOT_INITIALIZED'} haveS1=${haveS1} haveS2=${haveS2} haveS3=${haveS3} haveS4=${haveS4} haveS5=${haveS5} resumeFrom=S${resumeFromStage}`);

    let groundedProject = ensureGroundingForProject(project);

    // Research engine pre-stage 1 execution is ONLY required if S1 is not completed yet
    // and there are queries that are actually PLANNED or unexecuted.
    const hasPlannedQueries = (groundedProject.researchPackage?.queries || []).some((q) => q.status === 'PLANNED') ||
      !(groundedProject.researchPackage?.searchResults && groundedProject.researchPackage.searchResults.length > 0);

    if (
      !haveS1 &&
      groundedProject.researchPackage &&
      (groundedProject.researchPackage.researchRequirement === 'RESEARCH_REQUIRED' ||
        groundedProject.researchPackage.researchRequirement === 'RESEARCH_RECOMMENDED') &&
      hasPlannedQueries
    ) {
      log(0, 'Research Engine', 'Menjalankan query riset yang masih berstatus PLANNED sebelum Stage 1...', 'info', 'S1');
      const executedResearch = await executeResearchPackage(
        groundedProject.researchPackage,
        dependencies.researchEngine || new ResearchEngine()
      );
      const extractedResearch = extractClaimsFromEvidence(executedResearch).researchPackage;
      groundedProject = { ...groundedProject, researchPackage: extractedResearch };
      if (extractedResearch.claims.length > 0) {
        const resolved = resolveResearchPackage(extractedResearch);
        groundedProject = {
          ...groundedProject,
          researchPackage: resolved.researchPackage,
          contextPackage: resolved.contextPackage,
          sourceRegistry: resolved.researchPackage.sources,
        };
        log(0, 'Research Engine', `Research resolved: ${resolved.acceptedKnowledge.acceptedClaims.length} accepted claims, ${resolved.researchPackage.conflicts.length} conflicts preserved.`, 'success', 'S1');
      } else {
        log(0, 'Research Engine', 'Retrieval completed without ClaimRecords; evidence remains available but automatic claim extraction is not enabled.', 'warn', 'S1');
      }
    } else if (haveS1) {
      log(0, 'Research Engine', 'Fondasi S1 & Riset sudah lengkap. Melewati eksekusi pre-stage research.', 'info', 'S1');
    }

    await db.saveProject({
      ...groundedProject,
      status: 'processing',
      foundation_status: haveS5 ? 'ready' : haveS1 ? 'incomplete' : 'initializing',
      current_stage: resumeFromStage,
      error_message: null,
    });

    if (groundedProject.contextPackage) {
      const groundingValidation = validateGroundingContext(groundedProject.contextPackage);
      await db.saveProject({
        ...groundedProject,
        groundingVersion: GROUNDING_VERSION,
        contextPackage: groundedProject.contextPackage,
        sourceRegistry: groundedProject.contextPackage.sources,
        validationResult: groundingValidation,
        groundingStatus: groundedProject.contextPackage.groundingStatus,
      });
      if (groundingValidation.errors.length > 0) {
        log(0, 'Grounding Validator', `Grounding critical issues detected before Stage 1: ${groundingValidation.errors.join('; ')}`, 'warn', 'S1');
      }
    }

    const consistencyState = groundedProject.contextPackage
      ? createGroundingState(
          groundedProject.contextPackage,
          (groundedProject.researchPackage?.conflicts || []).filter((conflict) => conflict.status === 'UNRESOLVED')
        )
      : null;
    let continuityState = groundedProject.contextPackage
      ? createContinuityState(groundedProject.contextPackage)
      : null;
    if (continuityState) await db.saveProject({ ...groundedProject, continuityState });

    if (haveS5) {
      // Foundation fully materialized; nothing to re-run. Keep it ready so the
      // orchestrator does NOT trigger another init chain.
      await db.saveProject({
        ...(await db.getProject(projectId))!,
        foundation_status: 'ready',
        status: 'processing',
        error_message: null,
      });
      log(
        5,
        'Scene Breakdown & Duration',
        `Fondasi (S1-S5) sudah lengkap (${resumeScenes.length} scene). Melewati inisialisasi ulang.`,
        'success',
        'S5'
      );
      return { success: true };
    }

    // ==========================================
    // EXECUTION PREFLIGHT V2 (Live Model & Quota Verification)
    // ==========================================
    const stagesToCheck: StageCode[] = [];
    if (!haveS1) stagesToCheck.push('S1');
    if (!haveS2) stagesToCheck.push('S2');
    if (!haveS3) stagesToCheck.push('S3');
    if (!haveS4) stagesToCheck.push('S4');
    if (!haveS5) stagesToCheck.push('S5');

    if (stagesToCheck.length > 0) {
      log(0, 'Execution Preflight', 'Memeriksa ketersediaan & kuota semua model AI sebelum memulai pipeline...', 'info', 'S1');
      const preflightResult = await executionPreflight.checkExecutionPreflight(stagesToCheck);
      
      const readyModelsDisplay = preflightResult.readyModels && preflightResult.readyModels.length > 0
        ? preflightResult.readyModels.join(', ')
        : 'Standar AI Models';

      const poolInfo = preflightResult.totalCredentialsInPool && preflightResult.totalCredentialsInPool > 1
        ? ` (${preflightResult.totalCredentialsInPool} Key di Pool - Fast Rolling Siap)`
        : '';

      log(
        0,
        'Execution Preflight',
        `Hasil Pra-Pemeriksaan: ${preflightResult.viable ? `Model AI Siap (${readyModelsDisplay}) pada kredensial "${preflightResult.activeCredentialName || 'Default'}"${poolInfo}. Multi-key failover aktif.` : 'Pipeline diblokir: Tidak ada model/kuota yang mencukupi.'}`,
        preflightResult.viable ? 'info' : 'error',
        'S1'
      );

      if (!preflightResult.viable) {
        log(
          0,
          'Execution Preflight',
          `Pipeline dihentikan: ${preflightResult.reason}`,
          'error',
          'S1'
        );
        throw new Error(`Pipeline dihentikan lebih awal (Execution Preflight): ${preflightResult.reason}`);
      }
    }

    // ==========================================
    // STAGE 1: Story Understanding Agent (S1)
    // ==========================================
    if (stoppedProjects.has(projectId)) throw new PipelineStoppedError();
    let foundationData: ProjectFoundation;
    if (haveS1) {
      // S1 already persisted: reuse it, skip the LLM call.
      foundationData = resumeFoundation!;
      log(
        1,
        'Story Understanding',
        `Fondasi S1 sudah tersimpan (genre "${foundationData.genre}"). Melewati Stage 1.`,
        'warn',
        'S1'
      );
    } else {
      const s1Start = new Date().toISOString();
      const s1StartTime = Date.now();
      console.log(`[stage1] START stage=S1 project=${projectId} taskId=story_analysis ts=${s1Start}`);
      log(1, 'Story Understanding', `Memulai analisis naskah & fondasi cerita sinematik via Task Router [story_analysis]...`, 'info', 'S1');
      recordTelemetry(projectId, {
        stage: 1,
        stage_code: 'S1',
        scope: 'project',
        attempt: 1,
        started_at: s1Start,
        status: 'started',
      });

      let stage1Result;
      try {
        const stage1Runner = dependencies.stage1Runner || runStage1StoryUnderstanding;
        
        const stage1Input = {
          rawScript: project.raw_script,
          contextPackage: groundedProject.contextPackage || null,
          language: project.prompt_language,
          model: project.reasoning_config?.model_id,
          reasoningConfig: project.reasoning_config,
        };
        stage1Result = await stage1Runner(stage1Input);
        await enforceStageConsistency(projectId, 'S1', stage1Result, consistencyState);
        continuityState = await advanceContinuity(projectId, 'S1', { id: `project_${projectId}`, scene_number: 1, event: 'Stage 1', character_names: stage1Result.main_characters }, stage1Result, continuityState);
        const s1Duration = Date.now() - s1StartTime;
        recordTelemetry(projectId, {
          stage: 1,
          stage_code: 'S1',
          scope: 'project',
          attempt: 1,
          started_at: s1Start,
          completed_at: new Date().toISOString(),
          duration_ms: s1Duration,
          status: 'completed',
        });
        console.log(`[stage1] COMPLETE stage=S1 project=${projectId} elapsedMs=${s1Duration} genre=${stage1Result.genre} ts=${new Date().toISOString()}`);
      } catch (err: any) {
        const s1Duration = Date.now() - s1StartTime;
        const errType = classifyError(err);
        recordTelemetry(projectId, {
          stage: 1,
          stage_code: 'S1',
          scope: 'project',
          attempt: 1,
          started_at: s1Start,
          completed_at: new Date().toISOString(),
          duration_ms: s1Duration,
          status: 'failed',
          error_type: errType,
          error_message: err.message,
        });
        console.error(`[stage1] COMPLETE stage=S1 project=${projectId} elapsedMs=${s1Duration} status=failed errorType=${errType} error="${err.message}" ts=${new Date().toISOString()}`);
        throw err;
      }

      foundationData = {
        project_id: projectId,
        era: stage1Result.era,
        theme: stage1Result.theme,
        genre: stage1Result.genre,
        timeline: stage1Result.timeline,
        main_characters: stage1Result.main_characters,
        supporting_characters: stage1Result.supporting_characters,
        locations: stage1Result.locations,
        main_conflict: stage1Result.main_conflict,
        emotional_arc: stage1Result.emotional_arc,
        narrative_arc: stage1Result.narrative_arc,
        visual_tone: stage1Result.visual_tone,
        updated_at: new Date().toISOString(),

        // STORY BIBLE / RESEARCH ENGINE FIELDS
        is_historical_religious_biography: stage1Result.is_historical_religious_biography,
        research_basic_facts: stage1Result.research_basic_facts,
        research_timeline: stage1Result.research_timeline,
        research_era_context: stage1Result.research_era_context,
        research_sources: stage1Result.research_sources,

        act_1_world_setup: stage1Result.act_1_world_setup,
        act_2_human_element: stage1Result.act_2_human_element,
        act_3_rising_conflict: stage1Result.act_3_rising_conflict,
        act_4_climax_breath: stage1Result.act_4_climax_breath,
        act_5_legacy_meaning: stage1Result.act_5_legacy_meaning,
        narrative_style_mode: stage1Result.narrative_style_mode,
        islamic_validation_safeguard: stage1Result.islamic_validation_safeguard,
      };

      await db.saveProjectFoundation(foundationData);
      log(
        1,
        'Story Understanding',
        `Selesai. Genre: "${stage1Result.genre}", Era: "${stage1Result.era}", Terdeteksi ${(stage1Result.main_characters || []).length} karakter utama. Tersimpan di collection 'project_foundation'.`,
        'success',
        'S1',
        Date.now() - s1StartTime
      );
    }

    // ==========================================
    // STAGE 2 & STAGE 3: Concurrent Detection Pool
    // ==========================================
    if (stoppedProjects.has(projectId)) throw new PipelineStoppedError();
    await db.saveProject({ ...(await db.getProject(projectId))!, current_stage: 2 });
    
    let savedCharacters = resumeCharacters;
    let savedLocations = resumeLocations;
    let savedObjects = resumeObjects;

    let s2Result: any = null;
    let s3Result: any = null;

    const parallelPool: Promise<any>[] = [];

    // Stage 2 worker
    if (haveS2) {
      log(
        2,
        'Character Detection',
        `Character Bible sudah tersimpan (${savedCharacters.length} karakter). Melewati Stage 2.`,
        'warn',
        'S2'
      );
    } else {
      const s2Start = new Date().toISOString();
      const s2StartTime = Date.now();
      const selectedModelId = await resolveStageModel('S2', 'narrative', 'MEDIUM');
      log(2, 'Character Detection', `Mendeteksi profil karakter (Character Bible) & membaca database karakter yang ada [Model: ${selectedModelId}]...`, 'info', 'S2');
      recordTelemetry(projectId, {
        stage: 2,
        stage_code: 'S2',
        scope: 'project',
        attempt: 1,
        started_at: s2Start,
        status: 'started',
      });

      parallelPool.push(
        (async () => {
          try {
            s2Result = await runStage2CharacterDetection({
              rawScript: project.raw_script,
              foundation: foundationData,
              contextPackage: project.contextPackage || null,
              language: project.prompt_language,
              model: selectedModelId,
              reasoningConfig: project.reasoning_config,
            });
            savedCharacters = await db.saveAndMergeCharacters(projectId, s2Result);
            const s2Duration = Date.now() - s2StartTime;
            recordTelemetry(projectId, {
              stage: 2,
              stage_code: 'S2',
              scope: 'project',
              attempt: 1,
              started_at: s2Start,
              completed_at: new Date().toISOString(),
              duration_ms: s2Duration,
              status: 'completed',
            });
            log(
              2,
              'Character Detection',
              `Selesai. ${savedCharacters.length} karakter berhasil dipetakan dan disimpan ke collection 'characters' (merge verified).`,
              'success',
              'S2',
              s2Duration
            );
          } catch (err: any) {
            const s2Duration = Date.now() - s2StartTime;
            const errType = classifyError(err);
            recordTelemetry(projectId, {
              stage: 2,
              stage_code: 'S2',
              scope: 'project',
              attempt: 1,
              started_at: s2Start,
              completed_at: new Date().toISOString(),
              duration_ms: s2Duration,
              status: 'failed',
              error_type: errType,
              error_message: err.message,
            });
            throw err;
          }
        })()
      );
    }

    // Stage 3 worker
    if (haveS3) {
      log(
        3,
        'Location & Object Detection',
        `Location & Object Bible sudah tersimpan (${savedLocations.length} lokasi, ${savedObjects.length} objek). Melewati Stage 3.`,
        'warn',
        'S3'
      );
    } else {
      const s3Start = new Date().toISOString();
      const s3StartTime = Date.now();
      const selectedModelId = await resolveStageModel('S3', 'scene', 'MEDIUM');
      log(3, 'Location & Object Detection', `Mendeteksi set sinematik (Location Bible) dan properti kunci (Object Bible) [Model: ${selectedModelId}]...`, 'info', 'S3');
      recordTelemetry(projectId, {
        stage: 3,
        stage_code: 'S3',
        scope: 'project',
        attempt: 1,
        started_at: s3Start,
        status: 'started',
      });

      parallelPool.push(
        (async () => {
          try {
            s3Result = await runStage3LocationObjectDetection({
              rawScript: project.raw_script,
              foundation: foundationData,
              contextPackage: project.contextPackage || null,
              language: project.prompt_language,
              model: selectedModelId,
              reasoningConfig: project.reasoning_config,
            });
            savedLocations = await db.saveAndMergeLocations(projectId, s3Result.locations);
            savedObjects = await db.saveAndMergeObjects(projectId, s3Result.objects);
            const s3Duration = Date.now() - s3StartTime;
            recordTelemetry(projectId, {
              stage: 3,
              stage_code: 'S3',
              scope: 'project',
              attempt: 1,
              started_at: s3Start,
              completed_at: new Date().toISOString(),
              duration_ms: s3Duration,
              status: 'completed',
            });
            log(
              3,
              'Location & Object Detection',
              `Selesai. ${savedLocations.length} lokasi dan ${savedObjects.length} objek kunci tersimpan di collection 'locations' & 'objects'.`,
              'success',
              'S3',
              s3Duration
            );
          } catch (err: any) {
            const s3Duration = Date.now() - s3StartTime;
            const errType = classifyError(err);
            recordTelemetry(projectId, {
              stage: 3,
              stage_code: 'S3',
              scope: 'project',
              attempt: 1,
              started_at: s3Start,
              completed_at: new Date().toISOString(),
              duration_ms: s3Duration,
              status: 'failed',
              error_type: errType,
              error_message: err.message,
            });
            throw err;
          }
        })()
      );
    }

    // Run workers concurrently
    if (parallelPool.length > 0) {
      await Promise.all(parallelPool);
    }

    // Safe sequential post-processing for consistency and continuity
    if (s2Result) {
      await enforceStageConsistency(projectId, 'S2', s2Result, consistencyState);
      continuityState = await advanceContinuity(
        projectId,
        'S2',
        { id: `project_${projectId}`, scene_number: 2, event: 'Stage 2', character_names: s2Result.map((character: any) => character.name) },
        s2Result,
        continuityState,
        'within-scene',
        false
      );
    }

    if (s3Result) {
      await enforceStageConsistency(projectId, 'S3', s3Result, consistencyState);
      continuityState = await advanceContinuity(
        projectId,
        'S3',
        { id: `project_${projectId}`, scene_number: 3, event: 'Stage 3' },
        s3Result,
        continuityState,
        'within-scene',
        false
      );
    }

    // Persist final aggregated continuityState and advance project current_stage to S4
    const finalProjectState = await db.getProject(projectId);
    if (finalProjectState) {
      await db.saveProject({
        ...finalProjectState,
        current_stage: 4,
        continuityState: continuityState
      });
    }

    // ==========================================
    // STAGE 4: Narrative Structure Agent (S4)
    // ==========================================
    if (stoppedProjects.has(projectId)) throw new PipelineStoppedError();
    await db.saveProject({ ...(await db.getProject(projectId))!, current_stage: 4 });
    let narrativeBeats: typeof resumeNarrativeBeats;
    if (haveS4) {
      narrativeBeats = resumeNarrativeBeats;
      log(
        4,
        'Narrative Structure',
        'Narrative Beats (S4) sudah tersimpan. Melewati Stage 4.',
        'warn',
        'S4'
      );
    } else {
      const s4Start = new Date().toISOString();
      const s4StartTime = Date.now();
      // Dynamically resolve model with TaskProfile authority
      const selectedModelId = await resolveStageModel('S4', 'narrative', 'MEDIUM');
      log(
        4,
        'Narrative Structure',
        `Menyusun Peta Struktur Naratif 5-Babak Global (Beginning, Development, Climax, Consequence, Ending) [Model: ${selectedModelId}]...`,
        'info',
        'S4'
      );
      recordTelemetry(projectId, {
        stage: 4,
        stage_code: 'S4',
        scope: 'project',
        attempt: 1,
        started_at: s4Start,
        status: 'started',
      });

      try {
        narrativeBeats = await runStage4NarrativeStructure({
          rawScript: project.raw_script,
          foundation: foundationData,
          characters: savedCharacters,
          locations: savedLocations,
          contextPackage: project.contextPackage || null,
          language: project.prompt_language,
          model: selectedModelId, // Use dynamically resolved model
          reasoningConfig: project.reasoning_config,
        });
        await enforceStageConsistency(projectId, 'S4', narrativeBeats, consistencyState);
        continuityState = await advanceContinuity(projectId, 'S4', { id: `project_${projectId}`, scene_number: 4, event: 'Stage 4' }, narrativeBeats, continuityState);

        await db.saveProjectFoundation({
          ...foundationData,
          narrative_beats: narrativeBeats,
        });

        // Generate & save Cinematic Story Architecture (Cold Open, Acts/Babak, Sequences)
        const storyArch = synthesizeStoryArchitectureForLegacyProject(
          project,
          { ...foundationData, narrative_beats: narrativeBeats },
          []
        );
        await db.saveStoryArchitecture(storyArch);

        const s4Duration = Date.now() - s4StartTime;
        recordTelemetry(projectId, {
          stage: 4,
          stage_code: 'S4',
          scope: 'project',
          attempt: 1,
          started_at: s4Start,
          completed_at: new Date().toISOString(),
          duration_ms: s4Duration,
          status: 'completed',
        });
      } catch (err: any) {
        const s4Duration = Date.now() - s4StartTime;
        const errType = classifyError(err);
        recordTelemetry(projectId, {
          stage: 4,
          stage_code: 'S4',
          scope: 'project',
          attempt: 1,
          started_at: s4Start,
          completed_at: new Date().toISOString(),
          duration_ms: s4Duration,
          status: 'failed',
          error_type: errType,
          error_message: err.message,
        });
        throw err;
      }

      log(
        4,
        'Narrative Structure',
        'Selesai. Pemahaman global 5 babak naratif berhasil disusun dan tersimpan di collection \'project_foundation\'.',
        'success',
        'S4',
        Date.now() - s4StartTime
      );
    }

    // ==========================================
    // STAGE 5: Scene Breakdown & Duration Allocation Agent (S5)
    // ==========================================
    if (stoppedProjects.has(projectId)) throw new PipelineStoppedError();
    await db.saveProject({ ...(await db.getProject(projectId))!, current_stage: 5 });
    
    const targetTotalSec = project.total_duration_target_sec;
    const fixedSceneSec = project.scene_duration_sec ?? project.max_scene_shot_duration_sec;
    const maxSceneSec = fixedSceneSec ?? 30;

    log(
      5,
      'Scene Breakdown & Duration',
      `Memulai pembagian Scene Breakdown. Target total: ${targetTotalSec}s | ${fixedSceneSec ? `Fixed Scene Duration: ${fixedSceneSec}s (System Constrained)` : `Auto Mode (Max ${maxSceneSec}s per scene)`}...`,
      'info',
      'S5'
    );

    const MAX_RETRIES = 3;
    let attempt = 0;
    let validatedScenes: DetectedScene[] | null = null;
    let feedbackPrompt: string | undefined = undefined;
    let lastValidationError: string | undefined = undefined;

    // Canonical asset roster from S2/S3. S6's asset integrity gate resolves
    // scene.character_names / scene.location_name against these Bibles by name,
    // so S5 must emit the exact names or every scene gets BLOCKED at S6.
    const characterRoster = savedCharacters.map((character) => character.name).filter(Boolean);
    const locationRoster = savedLocations.map((location) => location.name).filter(Boolean);

    while (attempt < MAX_RETRIES) {
      attempt++;
      const s5AttemptStart = new Date().toISOString();
      const s5AttemptStartTime = Date.now();

      log(
        5,
        'Scene Breakdown & Duration',
        `Menjalankan generasi Scene Breakdown (Percobaan ${attempt}/${MAX_RETRIES})...`,
        'info',
        'S5'
      );
      recordTelemetry(projectId, {
        stage: 5,
        stage_code: 'S5',
        scope: 'project',
        attempt,
        started_at: s5AttemptStart,
        status: 'started',
      });

      try {
        // Dynamically resolve model with TaskProfile authority
        const selectedModelId = await resolveStageModel('S5', 'narrative', 'MEDIUM');
        
        const scenesAttempt = await runStage5SceneBreakdownAttempt({
          narrativeBeats,
          totalDurationTargetSec: targetTotalSec,
          maxSceneDurationSec: maxSceneSec,
          fixedSceneDurationSec: fixedSceneSec,
          allowFinalSceneOverride: project.allow_final_scene_override,
          contextPackage: project.contextPackage || null,
          language: project.prompt_language,
          model: selectedModelId, // Use dynamically resolved model
          reasoningConfig: project.reasoning_config,
          feedbackPrompt,
          characterRoster,
          locationRoster,
        });
        await enforceStageConsistency(projectId, 'S5', scenesAttempt, consistencyState);
        continuityState = await advanceContinuity(projectId, 'S5', { id: `project_${projectId}`, scene_number: 5, event: 'Stage 5' }, scenesAttempt, continuityState);

        // Backend Validation
        let validation = validateSceneDurations(
          scenesAttempt,
          targetTotalSec,
          maxSceneSec,
          project.prompt_language,
          fixedSceneSec,
          project.allow_final_scene_override
        );

        // S5 -> S6 asset contract. Any scene referencing a character/location
        // outside the Bible would be BLOCKED by the S6 asset integrity gate
        // after the full run, so it is caught here where the retry loop can
        // still regenerate against the exact roster.
        let assetNameValidation = validateSceneAssetNames(
          scenesAttempt,
          characterRoster,
          locationRoster,
          project.prompt_language
        );

        let semanticValidation = validateSceneSemanticPayload(
          scenesAttempt,
          project.prompt_language
        );

        if (!validation.valid || !assetNameValidation.valid || !semanticValidation.valid) {
          log(
            5,
            'Scene Breakdown & Duration',
            `Mendeteksi isu validasi pada Stage 5 (${!semanticValidation.valid ? 'Semantic Payload / Continuation Error' : 'Duration/Asset Error'}). Mencoba melakukan perbaikan deterministik lokal...`,
            'info',
            'S5'
          );

          try {
            // Repair asset names deterministically by forcing fallbacks if completely unresolvable
            const repairedScenes = scenesAttempt.map((scene) => {
              let repairedLoc = scene.location_name;
              if (locationRoster.length > 0) {
                if (!locationRoster.some((entry) => entry.toLowerCase() === (repairedLoc || '').toLowerCase())) {
                  // Fallback to the first canonical location if unresolvable
                  repairedLoc = locationRoster[0];
                }
              }

              let repairedChars = (scene.character_names || []).map((char) => {
                if (characterRoster.length > 0) {
                  if (!characterRoster.some((entry) => entry.toLowerCase() === char.toLowerCase())) {
                    // Fallback to the first canonical character if unresolvable
                    return characterRoster[0];
                  }
                }
                return char;
              });

              return {
                ...scene,
                location_name: repairedLoc,
                character_names: repairedChars,
              };
            });

            // Re-normalize durations deterministically
            const fullyRepairedScenes = allocateAndNormalizeSceneDurations(
              repairedScenes,
              targetTotalSec,
              maxSceneSec,
              fixedSceneSec,
              project.allow_final_scene_override,
              project.prompt_language
            );

            // Re-validate the fully repaired scenes
            const repairedValidation = validateSceneDurations(
              fullyRepairedScenes,
              targetTotalSec,
              maxSceneSec,
              project.prompt_language,
              fixedSceneSec,
              project.allow_final_scene_override
            );

            const repairedAssetValidation = validateSceneAssetNames(
              fullyRepairedScenes,
              characterRoster,
              locationRoster,
              project.prompt_language
            );

            if (repairedValidation.valid && repairedAssetValidation.valid) {
              log(
                5,
                'Scene Breakdown & Duration',
                `Perbaikan lokal deterministik BERHASIL! Melewati retry AI.`,
                'success',
                'S5'
              );
              // Update scenesAttempt with the repaired ones
              scenesAttempt.length = 0;
              scenesAttempt.push(...fullyRepairedScenes);
              validation = repairedValidation;
              assetNameValidation = repairedAssetValidation;
            } else {
              log(
                5,
                'Scene Breakdown & Duration',
                `Perbaikan lokal deterministik tidak memenuhi kriteria validasi. Melanjutkan ke alur retry normal.`,
                'warn',
                'S5'
              );
            }
          } catch (repairErr: any) {
            log(
              5,
              'Scene Breakdown & Duration',
              `Gagal menjalankan perbaikan lokal deterministik: ${repairErr.message}. Melanjutkan ke alur retry normal.`,
              'warn',
              'S5'
            );
          }
        }

        if (validation.valid && assetNameValidation.valid && semanticValidation.valid) {
          validatedScenes = scenesAttempt;
          const s5Duration = Date.now() - s5AttemptStartTime;
          recordTelemetry(projectId, {
            stage: 5,
            stage_code: 'S5',
            scope: 'project',
            attempt,
            started_at: s5AttemptStart,
            completed_at: new Date().toISOString(),
            duration_ms: s5Duration,
            status: 'completed',
          });

          log(
            5,
            'Scene Breakdown & Duration',
            `Validasi lolos sempurna pada percobaan ke-${attempt}! Total durasi ${validation.totalCalculated}s === ${targetTotalSec}s. Seluruh ${scenesAttempt.length} scene valid.`,
            'success',
            'S5',
            s5Duration
          );
          break;
        } else {
          const combinedError = [validation.errorMessage, assetNameValidation.errorMessage, semanticValidation.errorMessage].filter(Boolean).join(' ');
          const combinedCorrective = [validation.correctivePrompt, assetNameValidation.correctivePrompt, semanticValidation.correctivePrompt || (semanticValidation.errorMessage ? `Fix semantic error: ${semanticValidation.errorMessage}` : '')].filter(Boolean).join(' ');
          lastValidationError = combinedError;
          const s5Duration = Date.now() - s5AttemptStartTime;
          recordTelemetry(projectId, {
            stage: 5,
            stage_code: 'S5',
            scope: 'project',
            attempt,
            started_at: s5AttemptStart,
            completed_at: new Date().toISOString(),
            duration_ms: s5Duration,
            status: attempt < MAX_RETRIES ? 'retrying' : 'failed',
            error_type: validation.valid ? 'schema_validation' : 'duration_mismatch',
            error_message: combinedError,
          });

          log(
            5,
            'Scene Breakdown & Duration',
            `Percobaan ${attempt} gagal validasi: ${combinedError}`,
            'warn',
            'S5'
          );

          if (attempt < MAX_RETRIES) {
            feedbackPrompt = combinedCorrective;
          }
        }
      } catch (err: any) {
        lastValidationError = err?.message || 'Error generating Stage 5';
        const s5Duration = Date.now() - s5AttemptStartTime;
        const errType = classifyError(err);
        recordTelemetry(projectId, {
          stage: 5,
          stage_code: 'S5',
          scope: 'project',
          attempt,
          started_at: s5AttemptStart,
          completed_at: new Date().toISOString(),
          duration_ms: s5Duration,
          status: attempt < MAX_RETRIES ? 'retrying' : 'failed',
          error_type: errType,
          error_message: lastValidationError,
        });

        log(
          5,
          'Scene Breakdown & Duration',
          `Error panggilan Stage 5 (Percobaan ${attempt}): ${lastValidationError}`,
          'warn',
          'S5'
        );
      }
    }

    if (!validatedScenes) {
      const finalErrorMsg = `Gagal memenuhi batasan durasi setelah ${MAX_RETRIES} kali percobaan: ${
        lastValidationError || 'Kendala validasi durasi scene.'
      }`;
      
      log(5, 'Scene Breakdown & Duration', finalErrorMsg, 'error', 'S5');

      await db.saveProject({
        ...(await db.getProject(projectId))!,
        status: 'failed',
        foundation_status: 'failed',
        error_message: finalErrorMsg,
        retry_count: attempt,
        duration_validation_passed: false,
      });

      return { success: false, error: finalErrorMsg };
    }

    // Save scenes to collection 'scenes'
    const savedScenes = await db.saveScenes(projectId, validatedScenes);

    // Initialize & Save Continuity Snapshot for each scene
    const charStates = await db.getCharacterContinuityStates(projectId);
    let prevSceneState: any = undefined;

    for (const sc of savedScenes) {
      const snap = buildContinuitySnapshot(
        savedCharacters,
        savedLocations,
        savedObjects,
        charStates,
        sc.scene_number,
        prevSceneState
      );
      await db.saveContinuitySnapshot(projectId, sc.scene_number, snap);
      await db.updateScene(sc.id!, {
        continuity_snapshot: snap,
        continuity_status: 'passed',
      });

      // Prepare state inheritance for next scene
      const charStateRecord: Record<string, any> = {};
      for (const c of snap.characters) {
        charStateRecord[c.name.toLowerCase()] = {
          costume_version: c.current_state.costume_version,
          head_cover: c.costume.head_cover?.value,
          outer_garment: c.costume.outer_garment?.value,
        };
      }
      prevSceneState = {
        scene_number: sc.scene_number,
        character_states: charStateRecord,
        location_name: sc.location_name,
      };
    }

    // Update Story Architecture with saved scenes
    const fullStoryArch = synthesizeStoryArchitectureForLegacyProject(
      project,
      { ...foundationData, narrative_beats: narrativeBeats },
      savedScenes
    );
    await db.saveStoryArchitecture(fullStoryArch);

    // Update project foundation status to READY
    await db.saveProject({
      ...(await db.getProject(projectId))!,
      foundation_status: 'ready',
      duration_validation_passed: true,
      retry_count: attempt,
      error_message: null,
    });

    log(
      5,
      'Scene Breakdown & Duration',
      `Inisialisasi Fondasi Proyek (S1–S5) SELESAI. ${savedScenes.length} adegan siap diproduksi di tahap S6–S8.`,
      'success',
      'S5'
    );

    return { success: true };
  } catch (err: any) {
    const errorMsg = err?.message || 'Terjadi kesalahan pada inisialisasi fondasi proyek (S1-S5)';
    log(
      (await db.getProject(projectId))?.current_stage || 1,
      'Project Initialization',
      `Fatal error: ${errorMsg}`,
      'error'
    );

    await db.saveProject({
      ...(await db.getProject(projectId))!,
      status: 'failed',
      foundation_status: 'failed',
      error_message: errorMsg,
    });

    return { success: false, error: errorMsg };
  }
}

/**
 * Runs Scene Generation Scope: Stages 6, 7, and 8 for a single scene.
 * NEVER re-runs Stages 1 to 5.
 */
export function runPipelineForScene(
  sceneId: string,
  logFn?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void,
  continuitySeed?: ReturnType<typeof createContinuityState> | null,
  runContext?: GenerationRunContext
): Promise<ScenePipelineResult> {
  const existing = singleScenePipelineInFlight.get(sceneId);
  if (existing) {
    console.log(`[scene-pipeline] JOIN in-flight single scene pipeline scene=${sceneId}`);
    return existing;
  }

  const promise = runPipelineForSceneImpl(sceneId, logFn, continuitySeed, runContext).finally(() => {
    singleScenePipelineInFlight.delete(sceneId);
  });
  singleScenePipelineInFlight.set(sceneId, promise);
  return promise;
}

async function runPipelineForSceneImpl(
  sceneId: string,
  logFn?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void,
  continuitySeed?: ReturnType<typeof createContinuityState> | null,
  runContext?: GenerationRunContext
): Promise<ScenePipelineResult> {
  const scene = await db.getScene(sceneId);
  if (!scene) {
    throw new Error(`Scene ${sceneId} tidak ditemukan.`);
  }

  const projectId = scene.project_id;
  if (stoppedProjects.has(projectId)) {
    throw new PipelineStoppedError();
  }
  // If manual single-scene trigger and project-wide is active, reject
  if (!runContext && (generateAllScenesInFlight.has(projectId) || orchestratedPipelineInFlight.has(projectId))) {
    throw new Error('Project-wide pipeline is currently running. Please wait for it to complete.');
  }

  const project = await db.getProject(projectId);
  if (!project) {
    throw new Error(`Project ${projectId} tidak ditemukan.`);
  }

  const sceneStartedAtMs = Date.now();
  const sceneConsistencyState = project.contextPackage
    ? createGroundingState(
        project.contextPackage,
        (project.researchPackage?.conflicts || []).filter((conflict) => conflict.status === 'UNRESOLVED')
      )
    : null;

  // Verification Guard: Check if Foundation (S1-S5) is ready
  const foundationCheck = await verifyProjectFoundation(projectId);
  if (!foundationCheck.ready) {
    const initResult = await runProjectInitialization(projectId, logFn);
    if (!initResult.success) {
      throw new Error(`Fondasi project (S1-S5) belum siap dan gagal diinisialisasi: ${initResult.error}`);
    }
  }

  const refreshedProject = (await db.getProject(projectId)) || project;
  let sceneContinuityState = continuitySeed || refreshedProject.continuityState || (refreshedProject.contextPackage ? createContinuityState(refreshedProject.contextPackage) : null);

  const foundation = await db.getProjectFoundation(projectId);
  const characters = await db.getCharacters(projectId);
  const locations = await db.getLocations(projectId);
  const objects = await db.getObjects(projectId);
  let assetIntegrityReport = createSceneAssetCoverageReport(
    scene,
    characters,
    locations,
    objects,
    project.contextPackage || null,
    sceneContinuityState
  );
  const log = (
    stage: number,
    stageName: string,
    message: string,
    level: 'info' | 'success' | 'warn' | 'error' = 'info',
    stageCode?: StageCode,
    durationMs?: number,
    errorType?: ErrorClassification
  ) => {
    safeAddLog(projectId, {
      stage,
      stage_name: stageName,
      stage_code: stageCode || (`S${stage}` as StageCode),
      scope: 'scene',
      message,
      level,
      duration_ms: durationMs,
      error_type: errorType,
      run_id: runContext?.runId,
    });
    if (logFn) logFn(stage, stageName, message, level);
  };

  try {
    assertSceneAssetCoverage(assetIntegrityReport);
  } catch (error) {
    const blocker = knownBlocker(error, 'S6');
    const result: ScenePipelineResult = blocker
      ? { sceneId, status: 'BLOCKED', success: false, blockers: [blocker], assetIntegrityReport, continuityState: sceneContinuityState }
      : { sceneId, status: 'FAILED', success: false, error: error instanceof Error ? error.message : String(error), assetIntegrityReport, continuityState: sceneContinuityState };
    if (blocker) {
      await persistBlockedScene(sceneId, blocker);
    } else {
      await db.updateScene(sceneId, { status: 'failed', pipeline_status: 'FAILED', blockers: [] });
    }
    await safePersistSceneSummary(projectId, runContext?.runId, sceneId, scene.scene_number, sceneStartedAtMs, result.status, result);
    return result;
  }

  await beginSceneExecution(sceneId);

  // ----------------------------------------------------
  // STAGE 6: Shot Breakdown Agent (S6, per scene with isolated retry)
  // ----------------------------------------------------
  log(6, 'Shot Breakdown Agent', `Scene #${scene.scene_number}: Memulai breakdown shot sinematik (${scene.duration_sec}s)...`, 'info', 'S6');

  const MAX_SHOT_RETRIES = 3;
  let validatedShots: DetectedShot[] | null = null;
  let feedbackPrompt: string | undefined = undefined;
  let lastShotError: string | undefined = undefined;

  for (let attempt = 1; attempt <= MAX_SHOT_RETRIES; attempt++) {
    const s6Start = new Date().toISOString();
    const s6StartTime = Date.now();
    recordTelemetry(projectId, {
      stage: 6,
      stage_code: 'S6',
      scope: 'scene',
      scene_id: sceneId,
      attempt,
      started_at: s6Start,
      status: 'started',
      run_id: runContext?.runId,
    }, runContext);

    try {
      // Dynamically resolve model with TaskProfile authority
      const selectedModelId = await resolveStageModel('S6', 'scene', 'MEDIUM');
      
      const shotsAttempt = await runStage6ShotBreakdownAttempt({
        scene,
        characters,
        locations,
        objects,
        contextPackage: project.contextPackage || null,
        language: project.prompt_language,
        model: selectedModelId, // Use dynamically resolved model
        reasoningConfig: project.reasoning_config,
        feedbackPrompt,
        onProgress: (msg) => log(6, 'Shot Breakdown Agent', msg, 'info', 'S6'),
      });
      await enforceStageConsistency(projectId, `S6:${sceneId}`, shotsAttempt, sceneConsistencyState);
      sceneContinuityState = await advanceContinuity(projectId, `S6:${sceneId}`, scene, shotsAttempt, sceneContinuityState, scene.continuity_scope || 'scene-boundary', false);
      assetIntegrityReport = validatePromptCoverage(assetIntegrityReport, JSON.stringify({ scene, shots: shotsAttempt }));
      assertSceneAssetCoverage(assetIntegrityReport);

      // Strict Shot Duration Total Validation
      const durationValidation = validateShotDurationTotal(scene, shotsAttempt);
      const comprehensiveValidation = validateShotBreakdown(shotsAttempt, scene.duration_sec, project.prompt_language);

      if (durationValidation.valid && comprehensiveValidation.valid) {
        validatedShots = shotsAttempt;
        const s6Duration = Date.now() - s6StartTime;
        recordTelemetry(projectId, {
          stage: 6,
          stage_code: 'S6',
          scope: 'scene',
          scene_id: sceneId,
          attempt,
          started_at: s6Start,
          completed_at: new Date().toISOString(),
          duration_ms: s6Duration,
          status: 'completed',
          run_id: runContext?.runId,
        }, runContext);

        log(
          6,
          'Shot Breakdown Agent',
          `Scene #${scene.scene_number}: Validasi ${shotsAttempt.length} shot lolos! Total ${durationValidation.total}s === ${scene.duration_sec}s.`,
          'success',
          'S6',
          s6Duration
        );
        break;
      } else {
        lastShotError = durationValidation.error || comprehensiveValidation.errorMessage;
        const s6Duration = Date.now() - s6StartTime;
        recordTelemetry(projectId, {
          stage: 6,
          stage_code: 'S6',
          scope: 'scene',
          scene_id: sceneId,
          attempt,
          started_at: s6Start,
          completed_at: new Date().toISOString(),
          duration_ms: s6Duration,
          status: attempt < MAX_SHOT_RETRIES ? 'retrying' : 'failed',
          error_type: 'duration_mismatch',
          error_message: lastShotError,
          run_id: runContext?.runId,
        }, runContext);

        log(
          6,
          'Shot Breakdown Agent',
          `Scene #${scene.scene_number}: Percobaan ${attempt} belum lolos: ${lastShotError}`,
          'warn',
          'S6'
        );

        if (attempt < MAX_SHOT_RETRIES) {
          // Standardized duration correction prompt (Section C)
          feedbackPrompt = `The previous shot breakdown has an invalid total duration. Scene duration: ${scene.duration_sec} seconds. Generated shot total: ${durationValidation.total} seconds. Correct ONLY the shot durations so that the total equals exactly ${scene.duration_sec} seconds. Do not change the scene narrative, characters, locations, or dramatic intent.`;
        }
      }
    } catch (err: any) {
      lastShotError = err?.message || 'Error executing Stage 6';
      const s6Duration = Date.now() - s6StartTime;
      const errType = classifyError(err);
      const blocker = knownBlocker(err, `S6:${sceneId}`);
      const retryable = isRetryableSceneError(err, errType);
      recordTelemetry(projectId, {
        stage: 6,
        stage_code: 'S6',
        scope: 'scene',
        scene_id: sceneId,
        attempt,
        started_at: s6Start,
        completed_at: new Date().toISOString(),
        duration_ms: s6Duration,
        status: blocker ? 'blocked' : retryable && attempt < MAX_SHOT_RETRIES ? 'retrying' : 'failed',
        error_type: errType,
        error_message: lastShotError,
        run_id: runContext?.runId,
      }, runContext);

      log(
        6,
        'Shot Breakdown Agent',
        `Scene #${scene.scene_number}: Error percobaan ${attempt}: ${lastShotError}`,
        'warn',
        'S6'
      );
      if (blocker) {
        await persistBlockedScene(sceneId, blocker);
        const result: ScenePipelineResult = { sceneId, status: 'BLOCKED', success: false, blockers: [blocker], assetIntegrityReport, continuityState: sceneContinuityState };
        await safePersistSceneSummary(projectId, runContext?.runId, sceneId, scene.scene_number, sceneStartedAtMs, result.status, result);
        return result;
      }
      if (!retryable) {
        await db.updateScene(sceneId, { status: 'failed', pipeline_status: 'FAILED', blockers: [] });
        const result: ScenePipelineResult = { sceneId, status: 'FAILED', success: false, error: lastShotError, assetIntegrityReport, continuityState: sceneContinuityState };
        await safePersistSceneSummary(projectId, runContext?.runId, sceneId, scene.scene_number, sceneStartedAtMs, result.status, result);
        return result;
      }
    }
  }

  if (!validatedShots) {
    await db.updateScene(sceneId, { status: 'shot_breakdown_failed' });
    log(
      6,
      'Shot Breakdown Agent',
      `Scene #${scene.scene_number} gagal shot breakdown setelah ${MAX_SHOT_RETRIES} percobaan: ${lastShotError}.`,
      'error',
      'S6'
    );
    const result: ScenePipelineResult = { sceneId, status: 'FAILED', success: false, error: lastShotError, assetIntegrityReport, continuityState: sceneContinuityState };
    await safePersistSceneSummary(projectId, runContext?.runId, sceneId, scene.scene_number, sceneStartedAtMs, result.status, result);
    return result;
  }

  // Derive beats & cinematic grammar for the scene
  const sceneBeats = deriveBeatsForScene(scene, validatedShots as any);
  await db.updateScene(sceneId, { beats: sceneBeats });

  // Save shots to DB with narrative modes and cinematic grammar
  const enhancedShots = validatedShots.map((s: any, sIdx: number) => {
    const assignedBeat = sceneBeats.find(b => b.beat_number === s.beat_number) || sceneBeats[sIdx % sceneBeats.length];
    const mode = (s.narrative_mode || (s.dialogue && s.dialogue.length > 0 ? 'DIALOGUE' : 'ACTION')) as NarrativeMode;
    const grammar = CINEMATIC_GRAMMAR_GUIDELINES[mode] || CINEMATIC_GRAMMAR_GUIDELINES.ACTION;
    return {
      ...s,
      beat_id: assignedBeat?.beat_id || assignedBeat?.id,
      narrative_mode: mode,
      cinematic_grammar: {
        recommendedFraming: grammar.recommendedFraming,
        cameraMovement: grammar.cameraMovement,
        lightingAndMood: grammar.lightingAndMood,
        audioFocus: grammar.audioFocus,
      },
    };
  });

  const savedShots = await db.saveShots(sceneId, projectId, enhancedShots);

  // ----------------------------------------------------
  // STAGE 7: Master Frame & Image Prompt Agent (S7, per scene prompt-only)
  // ----------------------------------------------------
  const s7Start = new Date().toISOString();
  const s7StartTime = Date.now();
  log(7, 'Master Frame & Image Prompt', `Scene #${scene.scene_number}: Merancang Master Frame Image Prompt (Target: Nano Banana Pro)...`, 'info', 'S7');
  recordTelemetry(projectId, {
    stage: 7,
    stage_code: 'S7',
    scope: 'scene',
    scene_id: sceneId,
    attempt: 1,
    started_at: s7Start,
    status: 'started',
    run_id: runContext?.runId,
  }, runContext);

  try {
    // Dynamically resolve model with TaskProfile authority
    const selectedModelId = await resolveStageModel('S7', 'image', 'MEDIUM');
    
    const stage7Result = await runStage7MasterFrameAndImagePrompt({
      scene,
      foundation,
      characters,
      locations,
      objects,
      contextPackage: project.contextPackage || null,
      continuityState: sceneContinuityState,
      language: project.prompt_language,
      model: selectedModelId, // Use dynamically resolved model
      reasoningConfig: project.reasoning_config,
    });
    await enforceStageConsistency(projectId, `S7:${sceneId}`, stage7Result, sceneConsistencyState);
    sceneContinuityState = await advanceContinuity(projectId, `S7:${sceneId}`, scene, stage7Result, sceneContinuityState, 'within-scene', false);
    assetIntegrityReport = validateMasterFrameCoverage(assetIntegrityReport, JSON.stringify(stage7Result));
    assertSceneAssetCoverage(assetIntegrityReport);

    const compiledMasterPrompt = stage7Result.compiledPromptText || stage7Result.masterFramePromptText || (stage7Result.promptJson ? `${stage7Result.promptJson.subject || ''}. Location: ${stage7Result.promptJson.location || ''}. Lighting: ${stage7Result.promptJson.lighting || ''}. Style: ${stage7Result.promptJson.cinematic_style || ''}` : '');
    await db.updateScene(sceneId, {
      master_image_prompt: compiledMasterPrompt,
      master_image_prompt_json: stage7Result.promptJson,
      image_gen_status: 'success',
      image_gen_error: null,
    });

    const s7Duration = Date.now() - s7StartTime;
    recordTelemetry(projectId, {
      stage: 7,
      stage_code: 'S7',
      scope: 'scene',
      scene_id: sceneId,
      attempt: 1,
      started_at: s7Start,
      completed_at: new Date().toISOString(),
      duration_ms: s7Duration,
      status: 'completed',
      run_id: runContext?.runId,
    }, runContext);

    log(7, 'Master Frame & Image Prompt', `Scene #${scene.scene_number}: Master Image Prompt berhasil dirumuskan & siap dipakai!`, 'success', 'S7', s7Duration);
  } catch (err: any) {
    const errMsg = err?.message || 'Error generating master frame prompt';
    const errType = classifyError(err);
    const blocker = knownBlocker(err, `S7:${sceneId}`);
    if (blocker) {
      await persistBlockedScene(sceneId, blocker);
      const result: ScenePipelineResult = { sceneId, status: 'BLOCKED', success: false, blockers: [blocker], assetIntegrityReport, continuityState: sceneContinuityState };
      await safePersistSceneSummary(projectId, runContext?.runId, sceneId, scene.scene_number, sceneStartedAtMs, result.status, result);
      return result;
    }
    const s7Duration = Date.now() - s7StartTime;
    await db.updateScene(sceneId, {
      image_gen_status: 'failed',
      image_gen_error: errMsg,
    });
    recordTelemetry(projectId, {
      stage: 7,
      stage_code: 'S7',
      scope: 'scene',
      scene_id: sceneId,
      attempt: 1,
      started_at: s7Start,
      completed_at: new Date().toISOString(),
      duration_ms: s7Duration,
      status: 'failed',
      error_type: errType,
      error_message: errMsg,
      run_id: runContext?.runId,
    }, runContext);
    log(7, 'Master Frame & Image Prompt', `Scene #${scene.scene_number}: Error Stage 7: ${errMsg}`, 'warn', 'S7');
  }

  // Reload scene to get updated master frame
  const currentScene = (await db.getScene(sceneId)) || scene;

  // ----------------------------------------------------
  // STAGE 8: Video Prompt Agent (S8)
  // ----------------------------------------------------
  log(8, 'Video Prompt Agent', `Scene #${scene.scene_number}: Merumuskan Video Prompt...`, 'info', 'S8');
  
  let successfulShotsCount = 0;
  let failedShotsCount = 0;

  for (let idx = 0; idx < savedShots.length; idx++) {
    const shot = savedShots[idx];
    if (idx > 0) {
      // Pacing delay between shots
      await new Promise((resolve) => setTimeout(resolve, 400));
    }

    const s8Start = new Date().toISOString();
    const s8StartTime = Date.now();
    recordTelemetry(projectId, {
      stage: 8,
      stage_code: 'S8',
      scope: 'shot',
      scene_id: sceneId,
      shot_id: shot.id,
      attempt: 1,
      started_at: s8Start,
      status: 'started',
      run_id: runContext?.runId,
    }, runContext);

    try {
      const stage8Result = await runStage8VideoPrompt({
        scene: currentScene,
        shot,
        shotIndex: idx,
        totalShotsInScene: savedShots.length,
        masterFrameImageUrl: currentScene.master_frame_image_url,
        foundation,
        characters,
        locations,
        videoModels: project.video_model || ['veo'],
        includeSeedance: !!project.include_seedance_format,
        language: project.prompt_language,
        model: project.ai_model === 'auto' ? undefined : project.ai_model,
        reasoningConfig: project.reasoning_config,
        contextPackage: project.contextPackage || null,
        continuityState: sceneContinuityState,
      });
      await enforceStageConsistency(projectId, `S8:${sceneId}:${shot.id}`, stage8Result, sceneConsistencyState);
      sceneContinuityState = await advanceContinuity(projectId, `S8:${sceneId}:${shot.id}`, currentScene, stage8Result, sceneContinuityState, 'within-scene', false);
      assetIntegrityReport = validateVideoPromptCoverage(assetIntegrityReport, JSON.stringify(stage8Result), true);
      assertSceneAssetCoverage(assetIntegrityReport);

      if (shot.id) {
        await db.saveVideoPrompts(shot.id, sceneId, projectId, stage8Result.prompts);
        
        // Save banana_image / banana_master_frame prompt as the shot's master_image_prompt
        const bananaImageStill = stage8Result.stills.find((s) => s.target === 'banana_image' || s.target === 'banana_master_frame');
        const veoPrompt = stage8Result.prompts.find((p) => p.target_platform === 'veo');
        const seedancePrompt = stage8Result.prompts.find((p) => p.target_platform === 'seedance');

        const shotUpdates: any = {};
        if (bananaImageStill?.prompt_text) {
          shotUpdates.master_image_prompt = bananaImageStill.prompt_text;
        }
        if (veoPrompt?.timeline_json?.prompt) {
          shotUpdates.video_prompt = veoPrompt.timeline_json.prompt;
        }
        if (seedancePrompt?.timeline_json?.shot_breakdown || seedancePrompt?.timeline_json?.prompt) {
          shotUpdates.seedance_prompt = seedancePrompt.timeline_json?.shot_breakdown || seedancePrompt.timeline_json?.prompt;
        }
        if (Object.keys(shotUpdates).length > 0) {
          await db.updateShot(shot.id, shotUpdates);
        }
      }

      const hasFailed = stage8Result.prompts.some((p) => p.status === 'video_prompt_failed');
      const s8Duration = Date.now() - s8StartTime;

      if (hasFailed) {
        failedShotsCount++;
        const failedPlatforms = stage8Result.prompts
          .filter((p) => p.status === 'video_prompt_failed')
          .map((p) => p.target_platform)
          .join(', ');
        
        recordTelemetry(projectId, {
          stage: 8,
          stage_code: 'S8',
          scope: 'shot',
          scene_id: sceneId,
          shot_id: shot.id,
          attempt: 1,
          started_at: s8Start,
          completed_at: new Date().toISOString(),
          duration_ms: s8Duration,
          status: 'failed',
          error_type: 'schema_validation',
          error_message: `Gagal pada platform ${failedPlatforms}`,
          run_id: runContext?.runId,
        }, runContext);

        log(
          8,
          'Video Prompt Agent',
          `Shot #${shot.shot_number}: Gagal pada platform (${failedPlatforms}) setelah 3x retry (ditandai 'video_prompt_failed').`,
          'warn',
          'S8'
        );
      } else {
        successfulShotsCount++;
        recordTelemetry(projectId, {
          stage: 8,
          stage_code: 'S8',
          scope: 'shot',
          scene_id: sceneId,
          shot_id: shot.id,
          attempt: 1,
          started_at: s8Start,
          completed_at: new Date().toISOString(),
          duration_ms: s8Duration,
          status: 'completed',
          run_id: runContext?.runId,
        }, runContext);
      }
    } catch (err: any) {
      failedShotsCount++;
      const s8Duration = Date.now() - s8StartTime;
      const errType = classifyError(err);
      const blocker = knownBlocker(err, `S8:${sceneId}:${shot.id}`);
      if (blocker) {
        await persistBlockedScene(sceneId, blocker);
        const result: ScenePipelineResult = { sceneId, status: 'BLOCKED', success: false, blockers: [blocker], assetIntegrityReport, continuityState: sceneContinuityState };
        await safePersistSceneSummary(projectId, runContext?.runId, sceneId, scene.scene_number, sceneStartedAtMs, result.status, result);
        return result;
      }
      recordTelemetry(projectId, {
        stage: 8,
        stage_code: 'S8',
        scope: 'shot',
        scene_id: sceneId,
        shot_id: shot.id,
        attempt: 1,
        started_at: s8Start,
        completed_at: new Date().toISOString(),
        duration_ms: s8Duration,
        status: 'failed',
        error_type: errType,
        error_message: err?.message || 'Error executing Stage 8',
        run_id: runContext?.runId,
      }, runContext);
      log(8, 'Video Prompt Agent', `Shot #${shot.shot_number} error: ${err?.message || err}`, 'warn', 'S8');
    }
  }

  try {
    await enforceStageConsistency(
      projectId,
      `FINAL:${sceneId}`,
      { scene: currentScene, shots: savedShots, videoPrompts: await db.getVideoPromptsByScene(sceneId) },
      sceneConsistencyState
    );
    sceneContinuityState = await advanceContinuity(projectId, `FINAL:${sceneId}`, currentScene, { scene: currentScene, shots: savedShots }, sceneContinuityState, 'within-scene', false);
  } catch (error) {
    const blocker = knownBlocker(error, `FINAL:${sceneId}`);
    if (blocker) {
      await persistBlockedScene(sceneId, blocker);
      return { sceneId, status: 'BLOCKED', success: false, blockers: [blocker], assetIntegrityReport, continuityState: sceneContinuityState };
    }
    await db.updateScene(sceneId, { status: 'failed', pipeline_status: 'FAILED', blockers: [] });
    return { sceneId, status: 'FAILED', success: false, error: error instanceof Error ? error.message : String(error), assetIntegrityReport, continuityState: sceneContinuityState };
  }

  // ----------------------------------------------------
  // Full Scene Production Prompt Generation (Phase 17-19)
  // ----------------------------------------------------
  const snapshot = await db.getContinuitySnapshot(projectId, scene.scene_number);
  const fullScenePrompt = buildFullScenePrompt(currentScene, savedShots, snapshot);

  // ----------------------------------------------------
  // Continuity Validation & Auto-Correction (Phase 11-13)
  // ----------------------------------------------------
  // Pass the runtime sceneContinuityState so S8 validates the mutable scene-to-scene state
  // advanced by S6 (advanceContinuity), not only the static S5 baseline snapshot.
  const continuityResult = validateSceneContinuity(currentScene, savedShots, snapshot, sceneContinuityState);
  let continuityStatus: 'passed' | 'warning' | 'continuity_failed' = 'passed';
  let continuityViolations = continuityResult.violations;

  if (!continuityResult.valid) {
    log(
      8,
      'Continuity Engine',
      `Scene #${scene.scene_number}: Terdeteksi ${continuityViolations.length} inkonsistensi kontinuitas. Menjalankan auto-koreksi prompt...`,
      'warn',
      'S8'
    );

    // Auto-correction on generated shot prompts
    const shotPrompts = await db.getVideoPromptsByScene(sceneId);
    let correctedCount = 0;

    for (const vp of shotPrompts) {
      const originalPrompt = vp.timeline_json?.prompt || '';
      if (!originalPrompt) continue;
      const { correctedText, fixesApplied } = applyContinuityCorrectionToPrompt(originalPrompt, continuityViolations, snapshot);
      if (correctedText !== originalPrompt) {
        await db.saveSingleVideoPrompt({
          ...vp,
          timeline_json: {
            ...vp.timeline_json,
            prompt: correctedText,
          },
        });
        correctedCount++;
      }
    }

    if (correctedCount > 0) {
      log(
        8,
        'Continuity Engine',
        `Scene #${scene.scene_number}: Berhasil mengkoreksi otomatis ${correctedCount} prompt video untuk mematuhi lock kontinuitas.`,
        'info',
        'S8'
      );
    }

    // Re-evaluate severity after auto-correction
    const hasCritical = continuityViolations.some(v => v.severity === 'critical');
    const hasHigh = continuityViolations.some(v => v.severity === 'high');

    if (hasCritical || (hasHigh && correctedCount === 0)) {
      continuityStatus = 'continuity_failed';
    } else {
      continuityStatus = 'warning';
    }
  } else {
    log(
      8,
      'Continuity Engine',
      `Scene #${scene.scene_number}: Validasi kontinuitas (karakter, kostum, latar, objek) LOLOS 100%.`,
      'success',
      'S8'
    );
  }

  // Scene status evaluation
  let sceneFinalStatus: 'ready' | 'incomplete' | 'continuity_failed' = failedShotsCount > 0 ? 'incomplete' : 'ready';
  if (continuityStatus === 'continuity_failed') {
    sceneFinalStatus = 'continuity_failed';
  }

  await db.updateScene(sceneId, {
    status: sceneFinalStatus,
    full_scene_prompt: fullScenePrompt,
    full_scene_prompt_status: 'ready',
    continuity_status: continuityStatus,
    continuity_violations: continuityViolations,
  });
  await persistReadyScene(sceneId, continuityStatus, continuityViolations);

  if (failedShotsCount > 0 || continuityStatus === 'continuity_failed') {
    log(
      8,
      'Video Prompt Agent',
      `Scene #${scene.scene_number}: Status final: '${sceneFinalStatus}'. (${successfulShotsCount} shot berhasil, ${failedShotsCount} shot gagal, kontinuitas: ${continuityStatus}).`,
      'warn',
      'S8'
    );
  } else {
    log(
      8,
      'Video Prompt Agent',
      `Scene #${scene.scene_number}: Seluruh video prompt (${savedShots.length} shot) & Full Scene Prompt siap produksi (status: 'ready')!`,
      'success',
      'S8'
    );
  }

  const currentBlockers: ScenePipelineBlocker[] = continuityStatus === 'continuity_failed'
    ? continuityViolations.map((violation) => ({ code: 'CONTINUITY_BLOCKED', severity: 'BLOCKING', message: violation.message, stage: 'FINAL' }))
    : [];
  const currentStatus = resolveCurrentSceneStatus(currentBlockers, failedShotsCount > 0);
  const result: ScenePipelineResult = { sceneId, status: currentStatus, success: currentStatus === 'READY', blockers: currentBlockers, shots: savedShots, assetIntegrityReport, continuityState: sceneContinuityState, error: currentStatus === 'READY' ? undefined : `Scene final status: ${currentStatus}` };
  await safePersistSceneSummary(projectId, runContext?.runId, sceneId, scene.scene_number, sceneStartedAtMs, currentStatus, result);
  return result;
}

function mergeContinuityResults(
  base: ReturnType<typeof createContinuityState> | null,
  results: ScenePipelineResult[]
): ReturnType<typeof createContinuityState> | null {
  if (!base) return null;
  const merged = JSON.parse(JSON.stringify(base)) as ReturnType<typeof createContinuityState>;
  const sceneMap = new Map(merged.scenes.map((scene) => [scene.sceneId, scene]));
  for (const result of results.slice().sort((left, right) => left.sceneId.localeCompare(right.sceneId))) {
    for (const scene of result.continuityState?.scenes || []) sceneMap.set(scene.sceneId, scene);
  }
  merged.scenes = Array.from(sceneMap.values()).sort((left, right) => (left.sceneNumber ?? Number.MAX_SAFE_INTEGER) - (right.sceneNumber ?? Number.MAX_SAFE_INTEGER) || left.sceneId.localeCompare(right.sceneId));
  merged.activeEvents = Array.from(new Set(results.flatMap((result) => result.continuityState?.activeEvents || []))).sort((left, right) => left.localeCompare(right));
  merged.unresolvedIssues = Array.from(new Map(results.flatMap((result) => result.continuityState?.unresolvedIssues || []).map((issue) => [`${issue.sceneId || ''}:${issue.code}`, issue])).values()).sort((left, right) => `${left.sceneId || ''}:${left.code}`.localeCompare(`${right.sceneId || ''}:${right.code}`));
  return merged;
}

/**
 * Generates all scenes (S6-S8) with controlled worker concurrency (default = 2).
 * Does NOT re-run S1-S5 if foundation is already ready.
 */
export async function generateAllScenes(
  projectId: string,
  concurrency: number = 2,
  onProgress?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void,
  runContext?: GenerationRunContext
): Promise<{ success: boolean; totalScenes: number; readyScenes: number; failedScenes: number }> {
  const existingScenes = generateAllScenesInFlight.get(projectId);
  if (existingScenes) {
    console.log(`[scenes-pipeline] JOIN in-flight generateAllScenes project=${projectId}`);
    return existingScenes;
  }

  const existingOrchestrated = orchestratedPipelineInFlight.get(projectId);
  if (existingOrchestrated && !runContext) {
    console.log(`[scenes-pipeline] Awaiting active orchestrated pipeline to complete S6-S8 for project=${projectId}`);
    await existingOrchestrated;
    const scenes = await db.getScenes(projectId);
    const readyCount = scenes.filter((s) => s.status === 'ready' || s.pipeline_status === 'READY').length;
    const failedCount = scenes.filter((s) => s.status === 'failed' || s.pipeline_status === 'FAILED').length;
    return {
      success: failedCount === 0,
      totalScenes: scenes.length,
      readyScenes: readyCount,
      failedScenes: failedCount,
    };
  }

  const promise = generateAllScenesImpl(projectId, concurrency, onProgress, runContext).finally(() => {
    generateAllScenesInFlight.delete(projectId);
  });
  generateAllScenesInFlight.set(projectId, promise);
  return promise;
}

async function generateAllScenesImpl(
  projectId: string,
  concurrency: number = 2,
  onProgress?: (
    stage: number,
    stageName: string,
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error'
  ) => void,
  runContext?: GenerationRunContext
): Promise<{ success: boolean; totalScenes: number; readyScenes: number; failedScenes: number }> {
  const activeRunContext = runContext || createGenerationRunContext(projectId, concurrency);
  const project = await db.getProject(projectId);
  if (!project) {
    throw new Error(`Project ${projectId} tidak ditemukan.`);
  }

  // Verify foundation first
  const foundationCheck = await verifyProjectFoundation(projectId);
  if (!foundationCheck.ready) {
    const initResult = await runProjectInitialization(projectId, onProgress);
    if (!initResult.success) {
      throw new Error(`Fondasi project (S1-S5) gagal diinisialisasi: ${initResult.error}`);
    }
  }

  const scenes = (await db.getScenes(projectId)).slice().sort((left, right) => left.scene_number - right.scene_number || (left.id || '').localeCompare(right.id || ''));
  if (!scenes || scenes.length === 0) {
    throw new Error('Tidak ada scene yang ditemukan untuk digenerate.');
  }

  const log = (
    stage: number,
    stageName: string,
    message: string,
    level: 'info' | 'success' | 'warn' | 'error' = 'info'
  ) => {
    safeAddLog(projectId, { stage, stage_name: stageName, message, level, run_id: activeRunContext?.runId });
    if (onProgress) onProgress(stage, stageName, message, level);
  };

  // ==========================================
  // EXECUTION PREFLIGHT V2 (S6-S8 Live Verification)
  // ==========================================
  const pendingScenes = scenes.filter((s) => !(s.pipeline_status === 'READY' || s.status === 'ready'));
  if (pendingScenes.length > 0) {
    log(6, 'Execution Preflight', 'Memeriksa ketersediaan & kuota model AI untuk Tahap S6-S8...', 'info');
    const preflightResult = await executionPreflight.checkExecutionPreflight(['S6', 'S7', 'S8']);
    
    const readyModelsDisplay = preflightResult.readyModels && preflightResult.readyModels.length > 0
      ? preflightResult.readyModels.join(', ')
      : 'Standar AI Models';

    const poolInfo = preflightResult.totalCredentialsInPool && preflightResult.totalCredentialsInPool > 1
      ? ` (${preflightResult.totalCredentialsInPool} Key di Pool - Fast Rolling Siap)`
      : '';

    log(
      6,
      'Execution Preflight',
      `Hasil Pra-Pemeriksaan: ${preflightResult.viable ? `Model AI Siap (${readyModelsDisplay}) pada kredensial "${preflightResult.activeCredentialName || 'Default'}"${poolInfo}. Multi-key failover aktif.` : 'Pipeline diblokir: Tidak ada model/kuota yang mencukupi.'}`,
      preflightResult.viable ? 'info' : 'error'
    );

    if (!preflightResult.viable) {
      log(
        6,
        'Execution Preflight',
        `Pipeline dihentikan: ${preflightResult.reason}`,
        'error'
      );
      throw new Error(`Pipeline dihentikan lebih awal (Execution Preflight): ${preflightResult.reason}`);
    }
  }

  log(
    6,
    'Scene Generation Pool',
    `Memulai generasi ${scenes.length} scene (Tahap S6–S8) dengan konkurensi ${concurrency} worker...`,
    'info'
  );

  let currentIndex = 0;
  const workerResults: ScenePipelineResult[] = [];
  const completionOrder: string[] = [];
  const continuitySeed = project.continuityState || (project.contextPackage ? createContinuityState(project.contextPackage) : null);

  // Worker worker function with pacing
  async function worker(workerId: number) {
    // Initial offset to avoid simultaneous burst
    if (workerId > 1) {
      await new Promise((resolve) => setTimeout(resolve, (workerId - 1) * 1500));
    }

    while (currentIndex < scenes.length) {
      if (stoppedProjects.has(projectId)) {
        throw new PipelineStoppedError();
      }
      const idx = currentIndex++;
      const currentScene = scenes[idx];
      if (!currentScene.id) continue;

      if (currentScene.pipeline_status === 'READY' || currentScene.status === 'ready') {
        log(
          6,
          `Worker #${workerId}`,
          `Scene #${currentScene.scene_number} sudah selesai (READY). Melewati untuk menghemat resource.`,
          'success'
        );
        const existingShots = await db.getShotsByScene(currentScene.id);
        const integrityReports = project.assetIntegrityReports || [];
        const existingReport = integrityReports.find((r) => r.sceneId === currentScene.id);

        workerResults.push({
          status: 'READY',
          success: true,
          sceneId: currentScene.id,
          shots: existingShots,
          continuityState: currentScene.continuity_snapshot ? {
            project_id: projectId,
            characters: (currentScene.continuity_snapshot as any).characters || {},
            locations: (currentScene.continuity_snapshot as any).locations || {},
            objects: (currentScene.continuity_snapshot as any).objects || {},
            updated_at: (currentScene.continuity_snapshot as any).updated_at || new Date().toISOString(),
          } as any : null,
          assetIntegrityReport: existingReport,
        });
        completionOrder.push(currentScene.id);
        continue;
      }

      log(
        6,
        `Worker #${workerId}`,
        `Memproses Scene #${currentScene.scene_number} (${idx + 1}/${scenes.length})...`,
        'info'
      );

      try {
        let result: ScenePipelineResult;
        const activeSingleScene = singleScenePipelineInFlight.get(currentScene.id);
        if (activeSingleScene) {
          log(
            6,
            `Worker #${workerId}`,
            `Scene #${currentScene.scene_number} sedang diproses oleh pipeline scene tunggal aktif. Menunggu/Bergabung...`,
            'info'
          );
          result = await activeSingleScene;
        } else {
          result = await runPipelineForScene(currentScene.id, onProgress, continuitySeed ? JSON.parse(JSON.stringify(continuitySeed)) : null, activeRunContext);
        }
        workerResults.push(result);
        completionOrder.push(result.sceneId);
      } catch (err: any) {
        const failedResult: ScenePipelineResult = { sceneId: currentScene.id, status: 'FAILED', success: false, error: err?.message || String(err) };
        workerResults.push(failedResult);
        await db.updateScene(currentScene.id, { status: 'failed', pipeline_status: 'FAILED', blockers: [] });
        log(
          6,
          `Worker #${workerId}`,
          `Scene #${currentScene.scene_number} error tidak tertangani: ${err?.message || err}`,
          'warn'
        );
      }

      // Small pacing delay between consecutive scenes for the same worker
      if (currentIndex < scenes.length) {
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
    }
  }

  // Launch workers up to concurrency limit
  const activeWorkers: Promise<void>[] = [];
  const effectiveConcurrency = Math.min(concurrency, scenes.length);
  for (let w = 1; w <= effectiveConcurrency; w++) {
    activeWorkers.push(worker(w));
  }

  await Promise.all(activeWorkers);

  const orderedResults = workerResults.slice().sort((left, right) => {
    const leftScene = scenes.find((scene) => scene.id === left.sceneId);
    const rightScene = scenes.find((scene) => scene.id === right.sceneId);
    return (leftScene?.scene_number ?? Number.MAX_SAFE_INTEGER) - (rightScene?.scene_number ?? Number.MAX_SAFE_INTEGER) || left.sceneId.localeCompare(right.sceneId);
  });
  const reports = orderedResults.map((result) => result.assetIntegrityReport).filter((report): report is SceneAssetCoverageReport => Boolean(report));
  const updatedProject = await db.getProject(projectId);
  if (updatedProject) {
    const assetReports = [...(updatedProject.assetIntegrityReports || []).filter((report) => !reports.some((item) => item.sceneId === report.sceneId)), ...reports];
    const continuityState = mergeContinuityResults(continuitySeed, orderedResults);
      const aggregateProject = { ...updatedProject, continuityState, assetIntegrityReports: assetReports };
      const finalizationReport = evaluateFinalizationGate(aggregateProject, await Promise.all(scenes.map(async (scene) => {
        const current = await db.getScene(scene.id!);
        return { sceneId: scene.id, status: current?.pipeline_status || (current?.status === 'ready' ? 'READY' : current?.status) };
      })));
    const sceneBlockers: FinalizationBlocker[] = orderedResults.flatMap((result) => (result.blockers || []).map((blocker) => ({ code: blocker.code, layer: blocker.stage, message: blocker.message, sceneId: result.sceneId })));
    finalizationReport.blockerDetails = [...(finalizationReport.blockerDetails || []), ...sceneBlockers];
    finalizationReport.blockers = Array.from(new Set([...finalizationReport.blockers, ...sceneBlockers.map((blocker) => blocker.message)]));
    const hasFailed = orderedResults.some((result) => result.status === 'FAILED');
    const finalStatus = hasFailed ? 'failed' : finalizationReport.status === 'BLOCKED' ? 'blocked' : 'completed';
    await db.saveProject({
      ...aggregateProject,
      status: finalStatus,
      current_stage: 8,
      finalizationReport,
      error_message: hasFailed || finalizationReport.status === 'BLOCKED' ? `${orderedResults.filter((result) => result.status !== 'READY').length} dari ${scenes.length} scene memerlukan perhatian manual.` : null,
    });
  }

  const readyCount = orderedResults.filter((result) => result.status === 'READY').length;
  const blockedCount = orderedResults.filter((result) => result.status === 'BLOCKED').length;
  const failedCount = orderedResults.filter((result) => result.status === 'FAILED').length;

  const stageSummaries = await Promise.all(['S6', 'S7', 'S8'].map(async (stageCode) => {
    const stageEntries = (await db.getTelemetry(projectId)).filter((entry) => entry.run_id === activeRunContext?.runId && entry.stage_code === stageCode && typeof entry.duration_ms === 'number');
    const totalMs = stageEntries.reduce((sum, entry) => sum + (entry.duration_ms || 0), 0);
    return { stage_code: stageCode, count: stageEntries.length, total_ms: totalMs, average_ms: stageEntries.length ? totalMs / stageEntries.length : 0 };
  }));

  await safePersistRunSummary(projectId, activeRunContext?.runId, {
    run_id: activeRunContext?.runId,
    effective_concurrency: effectiveConcurrency,
    total_scenes: scenes.length,
    ready_scenes: readyCount,
    blocked_scenes: blockedCount,
    failed_scenes: failedCount,
    completion_order: completionOrder,
    started_at: activeRunContext?.startedAt || new Date().toISOString(),
    completed_at: new Date().toISOString(),
    duration_ms: Date.now() - (activeRunContext ? new Date(activeRunContext.startedAt).getTime() : Date.now()),
    stage_timings: Object.fromEntries(stageSummaries.map((summary) => [summary.stage_code, summary])),
  });

  log(
    8,
    'Scene Generation Pool',
    `Generasi seluruh scene selesai. ${readyCount} scene siap, ${failedCount} scene perlu perhatian.`,
    failedCount === 0 ? 'success' : 'warn'
  );

  return {
    success: orderedResults.every((result) => result.status === 'READY'),
    totalScenes: scenes.length,
    readyScenes: readyCount,
    failedScenes: failedCount,
  };
}

async function safePersistRunSummaryAtOrchestrator(
  projectId: string,
  runId: string | undefined,
  startedAt: string,
  effectiveConcurrency: number,
  scenesCount: number,
  readyScenes: number,
  blockedScenes: number,
  failedScenes: number,
  completionOrder: string[]
): Promise<void> {
  try {
    const durationMs = Date.now() - new Date(startedAt).getTime();
    const stageSummaries = await Promise.all(['S6', 'S7', 'S8'].map(async (stageCode) => {
      const stageEntries = (await db.getTelemetry(projectId)).filter((entry) => entry.run_id === runId && entry.stage_code === stageCode && typeof entry.duration_ms === 'number');
      const totalMs = stageEntries.reduce((sum, entry) => sum + (entry.duration_ms || 0), 0);
      return { stage_code: stageCode, count: stageEntries.length, total_ms: totalMs, average_ms: stageEntries.length ? totalMs / stageEntries.length : 0 };
    }));

    await recordTelemetry(projectId, {
      stage: 8,
      stage_code: 'S8',
      scope: 'project',
      started_at: startedAt,
      completed_at: new Date().toISOString(),
      duration_ms: durationMs,
      status: 'completed',
      summary_type: 'run',
      summary: {
        run_id: runId,
        effective_concurrency: effectiveConcurrency,
        total_scenes: scenesCount,
        ready_scenes: readyScenes,
        blocked_scenes: blockedScenes,
        failed_scenes: failedScenes,
        completion_order: completionOrder,
        started_at: startedAt,
        completed_at: new Date().toISOString(),
        duration_ms: durationMs,
        stage_timings: Object.fromEntries(stageSummaries.map((summary) => [summary.stage_code, summary])),
      },
      run_id: runId,
    }, { runId } as GenerationRunContext);
  } catch {
    // Observability must remain non-blocking.
  }
}

/**
 * Top-level Orchestrator:
 * 1. Checks foundation status; runs S1-S5 if not ready.
 * 2. Runs S6-S8 for all scenes with controlled concurrency.
 */
export function runOrchestratedPipeline(
  options: OrchestratorRunOptions
): Promise<{ success: boolean; error?: string; runId?: string }> {
  const existing = orchestratedPipelineInFlight.get(options.projectId);
  if (existing) {
    console.log(`[pipeline] JOIN in-flight orchestrated pipeline project=${options.projectId}`);
    if (options.onProgress) {
      if (!orchestratedPipelineListeners.has(options.projectId)) {
        orchestratedPipelineListeners.set(options.projectId, new Set());
      }
      orchestratedPipelineListeners.get(options.projectId)!.add(options.onProgress);
    }
    return existing;
  }
  if (options.onProgress) {
    if (!orchestratedPipelineListeners.has(options.projectId)) {
      orchestratedPipelineListeners.set(options.projectId, new Set());
    }
    orchestratedPipelineListeners.get(options.projectId)!.add(options.onProgress);
  }
  const promise = runOrchestratedPipelineImpl(options).finally(() => {
    orchestratedPipelineInFlight.delete(options.projectId);
    orchestratedPipelineListeners.delete(options.projectId);
  });
  orchestratedPipelineInFlight.set(options.projectId, promise);
  return promise;
}

async function runOrchestratedPipelineImpl({
  projectId,
  onProgress,
  runContext,
  sceneConcurrency,
}: OrchestratorRunOptions): Promise<{ success: boolean; error?: string; runId?: string }> {
  const project = await db.getProject(projectId);
  if (!project) {
    throw new Error(`Project with ID ${projectId} not found.`);
  }

  const activeRunContext = runContext ?? createGenerationRunContext(projectId, 2);
  const log = (
    stage: number,
    stageName: string,
    message: string,
    level: 'info' | 'success' | 'warn' | 'error' = 'info'
  ) => {
    safeAddLog(projectId, { stage, stage_name: stageName, message, level, run_id: activeRunContext.runId });
    const listeners = orchestratedPipelineListeners.get(projectId);
    if (listeners && listeners.size > 0) {
      for (const listener of listeners) {
        try {
          listener(stage, stageName, message, level);
        } catch {
          // Progress notification failure must be strictly non-fatal to backend pipeline
        }
      }
    } else if (onProgress) {
      try {
        onProgress(stage, stageName, message, level);
      } catch {
        // Non-fatal
      }
    }
  };

  try {
    const runStartedAt = new Date().toISOString();
    const completionOrder: string[] = [];
    await db.saveProject({
      ...(await db.getProject(projectId))!,
      active_run_id: activeRunContext.runId,
      latest_run_id: activeRunContext.runId,
      status: 'processing',
      current_stage: 1,
    });
    // Step 1: Project Initialization (S1-S5)
    const foundationCheck = await verifyProjectFoundation(projectId);
    if (!foundationCheck.ready) {
      if (foundationCheck.completed.length === 0) {
        log(1, 'Pipeline Orchestrator', `[Pipeline Orchestrator] run=${activeRunContext.runId} status=NOT_INITIALIZED. Menjalankan Tahap S1–S5...`, 'info');
      } else {
        const resumeStageNumber = foundationCheck.completed.length + 1;
        log(
          resumeStageNumber,
          'Pipeline Orchestrator',
          `[Pipeline Orchestrator] run=${activeRunContext.runId} status=PARTIAL (${foundationCheck.completed.length}/5 selesai: ${foundationCheck.completed.join(', ')}). Belum lengkap: ${foundationCheck.missing.join(', ')}. Melanjutkan dari Stage S${resumeStageNumber}...`,
          'info'
        );
      }
      const initResult = await runProjectInitialization(projectId, onProgress);
      if (!initResult.success) {
        return initResult;
      }
    } else {
      log(1, 'Pipeline Orchestrator', `[Pipeline Orchestrator] run=${activeRunContext.runId} status=READY. Fondasi proyek (S1–S5) sudah valid & siap. Melompati inisialisasi ulang.`, 'info');
    }

    // Step 2: Scene Generation (S6-S8) with configurable concurrency
    // Cascade: sceneConcurrency arg > runContext.concurrency > SCENE_GENERATION_CONCURRENCY env > default 2
    const envConcurrency = process.env.SCENE_GENERATION_CONCURRENCY
      ? parseInt(process.env.SCENE_GENERATION_CONCURRENCY, 10)
      : undefined;
    const resolvedConcurrency = sceneConcurrency ?? activeRunContext.concurrency ?? envConcurrency ?? 2;
    const sceneResult = await generateAllScenes(projectId, resolvedConcurrency, onProgress, activeRunContext);
    const blockedScenes = sceneResult.totalScenes - sceneResult.readyScenes - sceneResult.failedScenes;
    await safePersistRunSummaryAtOrchestrator(
      projectId,
      activeRunContext.runId,
      runStartedAt,
      resolvedConcurrency,
      sceneResult.totalScenes,
      sceneResult.readyScenes,
      blockedScenes,
      sceneResult.failedScenes,
      completionOrder
    );

    log(
      8,
      'Pipeline Orchestrator',
      `Pipeline selesai! ${sceneResult.readyScenes}/${sceneResult.totalScenes} scene siap untuk produksi.`,
      sceneResult.success ? 'success' : 'warn'
    );

    return {
      success: sceneResult.success,
      error: sceneResult.success ? undefined : `Pipeline aggregate status: ${sceneResult.failedScenes} scene(s) require attention.`,
      runId: activeRunContext.runId,
    };
  } catch (err: any) {
    const isStopped = err instanceof PipelineStoppedError || err?.name === 'PipelineStoppedError' || stoppedProjects.has(projectId);
    stoppedProjects.delete(projectId);
    const errorMsg = isStopped ? 'Pipeline dihentikan oleh pengguna.' : (err?.message || 'Terjadi kesalahan pada pipeline orchestrator.');
    
    log(
      (await db.getProject(projectId))?.current_stage || 1,
      isStopped ? 'Pipeline Stopped' : 'Pipeline Failure',
      isStopped ? `🛑 ${errorMsg}` : `Fatal error: ${errorMsg}`,
      isStopped ? 'warn' : 'error'
    );

    await db.saveProject({
      ...(await db.getProject(projectId))!,
      status: 'failed',
      error_message: errorMsg,
      active_run_id: activeRunContext.runId,
      latest_run_id: activeRunContext.runId,
    });

    return { success: false, error: errorMsg, runId: activeRunContext.runId };
  }
}

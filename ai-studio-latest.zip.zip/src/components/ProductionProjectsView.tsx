import React, { useState } from 'react';
import {
  Film,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Trash2,
  ArrowRight,
  Download,
  RotateCcw,
  Sparkles,
  X,
  Layers,
  Play,
  CheckSquare,
  Loader2,
} from 'lucide-react';
import { Project, PromptLanguage, ReasoningConfig } from '../types';
import { NewProjectForm } from './NewProjectForm';

interface ProductionProjectsViewProps {
  projects: Project[];
  activeProjectId: string | null;
  onSelectProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => Promise<void> | void;
  onCreateProject: (formData: {
    title: string;
    raw_script: string;
    total_duration_target_sec: number;
    max_scene_shot_duration_sec: number | null;
    prompt_language: PromptLanguage;
    ai_model?: string;
    reasoning_config?: ReasoningConfig;
  }) => Promise<void>;
  isCreating: boolean;
  onOpenPipelineModal?: () => void;
}

export const ProductionProjectsView: React.FC<ProductionProjectsViewProps> = ({
  projects,
  activeProjectId,
  onSelectProject,
  onDeleteProject,
  onCreateProject,
  isCreating,
  onOpenPipelineModal,
}) => {
  const [filter, setFilter] = useState<'all' | 'processing' | 'completed' | 'draft'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Bulk Delete State
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);
  const [bulkProgress, setBulkProgress] = useState({ current: 0, total: 0 });

  const handleDeleteConfirm = async () => {
    if (!projectToDelete) return;
    try {
      setIsDeleting(true);
      await onDeleteProject(projectToDelete.id);
      setProjectToDelete(null);
    } catch (err) {
      console.error('Gagal menghapus proyek:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredProjects = projects.filter((p) => {
    const title = p?.title || '';
    const script = p?.raw_script || (p as any)?.raw_synopsis || '';
    const query = (searchQuery || '').toLowerCase();
    const matchesSearch = title.toLowerCase().includes(query) || script.toLowerCase().includes(query);

    if (!matchesSearch) return false;

    if (filter === 'processing') return p.status === 'processing';
    if (filter === 'completed') return p.status === 'completed';
    if (filter === 'draft') return p.status === 'draft' || p.status === 'failed' || p.status === 'blocked';
    return true;
  });

  const ongoingCount = projects.filter((p) => p.status === 'processing').length;
  const completedCount = projects.filter((p) => p.status === 'completed').length;
  const draftCount = projects.filter((p) => p.status === 'draft' || p.status === 'failed' || p.status === 'blocked').length;

  const getFilterTabLabel = () => {
    if (filter === 'processing') return 'Sedang Berjalan';
    if (filter === 'completed') return 'Selesai';
    if (filter === 'draft') return 'Draft & Idle';
    return 'Semua Proyek';
  };

  const handleBulkDelete = async () => {
    if (filteredProjects.length === 0) return;
    setIsBulkDeleting(true);
    setBulkProgress({ current: 0, total: filteredProjects.length });

    try {
      for (let i = 0; i < filteredProjects.length; i++) {
        const proj = filteredProjects[i];
        setBulkProgress({ current: i + 1, total: filteredProjects.length });
        await onDeleteProject(proj.id);
      }
    } catch (err) {
      console.error('Gagal menghapus proyek massal:', err);
    } finally {
      setIsBulkDeleting(false);
      setIsBulkDeleteModalOpen(false);
      setBulkProgress({ current: 0, total: 0 });
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 pb-24 md:pb-16 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-200">
      {/* Production Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#181926] border border-[#2B2D44] p-6 rounded-3xl shadow-xl">
        <div>
          <div className="text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-400">
            PABRIK MANAJEMEN NASKAH &amp; PRODUKSI
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            Halaman Produksi Proyek
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Daftar seluruh proyek sinematik yang telah dibuat, berjalan, atau siap diolah di dalam Studio.
          </p>
        </div>

        <button
          onClick={() => setShowCreateForm(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold px-5 py-3 rounded-2xl text-xs shadow-lg shadow-indigo-600/30 transition transform active:scale-95 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Buat Proyek Baru
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              filter === 'all'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-[#1E2032] hover:bg-[#25283E] text-slate-400 border border-[#2B2D44]'
            }`}
          >
            <span>Semua Proyek</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-black/20">
              {projects.length}
            </span>
          </button>

          <button
            onClick={() => setFilter('processing')}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              filter === 'processing'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-[#1E2032] hover:bg-[#25283E] text-slate-400 border border-[#2B2D44]'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
            <span>Sedang Berjalan</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-black/20 text-indigo-300">
              {ongoingCount}
            </span>
          </button>

          <button
            onClick={() => setFilter('completed')}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              filter === 'completed'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-[#1E2032] hover:bg-[#25283E] text-slate-400 border border-[#2B2D44]'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
            <span>Selesai</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-black/20 text-emerald-300">
              {completedCount}
            </span>
          </button>

          <button
            onClick={() => setFilter('draft')}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              filter === 'draft'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-[#1E2032] hover:bg-[#25283E] text-slate-400 border border-[#2B2D44]'
            }`}
          >
            <span>Draft &amp; Idle</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-black/20 text-purple-300">
              {draftCount}
            </span>
          </button>
        </div>

        {/* Search Input & Bulk Delete Button */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full md:w-auto shrink-0">
          <div className="relative max-w-sm w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari naskah atau judul..."
              className="w-full bg-[#1B1C2E] border border-[#2B2D44] focus:border-indigo-500 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition"
            />
          </div>

          {filteredProjects.length > 0 && (
            <button
              onClick={() => setIsBulkDeleteModalOpen(true)}
              className="px-3.5 py-2.5 rounded-2xl text-xs font-bold bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 hover:text-rose-200 border border-rose-500/30 hover:border-rose-500/50 flex items-center justify-center gap-2 transition whitespace-nowrap shrink-0 shadow-sm cursor-pointer"
              title={`Hapus seluruh ${filteredProjects.length} proyek yang tampil pada tab ini`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Semua ({filteredProjects.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length === 0 ? (
        <div className="bg-[#1B1C2E] border border-dashed border-[#2B2D44] rounded-3xl p-12 text-center space-y-4">
          <Film className="w-12 h-12 text-slate-600 mx-auto" />
          <div>
            <h3 className="text-base font-bold text-slate-200">Tidak ada proyek ditemukan</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
              {searchQuery
                ? 'Tidak ada proyek yang sesuai dengan pencarian Anda.'
                : 'Belum ada proyek di kategori ini. Buat proyek baru untuk memulai.'}
            </p>
          </div>
          <button
            onClick={() => setShowCreateForm(true)}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-2xl shadow-lg transition inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Buat Proyek Baru
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((proj, idx) => {
            const isCurrent = activeProjectId === proj.id;
            const currentStage = proj.current_stage || 1;
            const progressPercent = Math.min(
              100,
              Math.round(((proj.status === 'completed' ? 8 : currentStage) / 8) * 100)
            );

            return (
              <div
                key={proj.id ? `proj-${proj.id}` : `proj-idx-${idx}`}
                className={`bg-[#1B1C2E] border rounded-3xl p-6 flex flex-col justify-between space-y-4 transition group shadow-xl relative overflow-hidden ${
                  isCurrent
                    ? 'border-indigo-500 ring-2 ring-indigo-500/20'
                    : 'border-[#2B2D44] hover:border-indigo-500/40'
                }`}
              >
                {/* Header Tag */}
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase bg-[#212335] text-slate-300 border border-[#2F324D]">
                    Target: {proj.total_duration_target_sec}s
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectProject(proj.id);
                        if (proj.status === 'processing') {
                          onOpenPipelineModal?.();
                        }
                      }}
                      className={`px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase transition ${
                        proj.status === 'completed'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : proj.status === 'processing'
                          ? 'bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30 animate-pulse cursor-pointer'
                          : 'bg-slate-700/30 text-slate-400'
                      }`}
                      title={proj.status === 'processing' ? 'Klik untuk melihat animasi loading kartu pipeline' : undefined}
                    >
                      {proj.status === 'processing' ? `Stage ${currentStage}/8 ✦` : proj.status}
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setProjectToDelete(proj);
                      }}
                      className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition"
                      title="Hapus Proyek"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Body Content */}
                <div className="space-y-2">
                  <h3 className="text-lg font-black text-white group-hover:text-indigo-300 transition line-clamp-1">
                    {proj.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                    {proj.raw_script}
                  </p>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] font-mono font-semibold">
                    <span className="text-slate-400">Kemajuan Stage</span>
                    <span className="text-indigo-400 font-bold">{progressPercent}%</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-[#212335] overflow-hidden p-0.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Footer Link CTA */}
                <div className="pt-3 border-t border-[#292B42] flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-500">
                    Model: {proj.ai_model || 'gemini-3.7-flash'}
                  </span>
                  <button
                    onClick={() => onSelectProject(proj.id)}
                    className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold px-4 py-2 rounded-xl text-xs shadow-md transition transform active:scale-95"
                  >
                    Masuk Studio Proyek
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Konfirmasi Hapus Massal Proyek Tab */}
      {isBulkDeleteModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-[#141624] border border-rose-500/40 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative overflow-hidden">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-rose-500/10 text-rose-400 border border-rose-500/20 shrink-0">
                  <Trash2 className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-rose-400">
                    Aksi Hapus Massal (Bulk Delete)
                  </span>
                  <h3 className="text-lg font-black text-white">
                    Hapus Semua Proyek ({filteredProjects.length})?
                  </h3>
                </div>
              </div>
              <button
                disabled={isBulkDeleting}
                onClick={() => setIsBulkDeleteModalOpen(false)}
                className="p-2 text-slate-400 hover:text-white bg-[#1C1E30] hover:bg-[#25283E] rounded-xl transition cursor-pointer disabled:opacity-50"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <p className="leading-relaxed">
                Anda akan menghapus seluruh <strong className="text-rose-300">{filteredProjects.length} proyek</strong> yang saat ini tampil di tab <strong className="text-indigo-300 font-bold">"{getFilterTabLabel()}"</strong>
                {searchQuery && <span> dengan filter pencarian <strong className="text-amber-300">"{searchQuery}"</strong></span>}.
              </p>

              {/* List preview of projects to be deleted */}
              <div className="bg-[#0B0C14] border border-[#23253A] rounded-2xl p-3 max-h-40 overflow-y-auto space-y-1.5 scrollbar-thin">
                {filteredProjects.map((proj, pIdx) => (
                  <div key={proj.id || pIdx} className="flex items-center justify-between text-[11px] font-mono py-1 border-b border-[#1A1C2C] last:border-0 text-slate-300">
                    <span className="truncate pr-2 font-sans font-medium text-slate-200">{pIdx + 1}. {proj.title}</span>
                    <span className="shrink-0 px-2 py-0.5 rounded text-[9px] bg-[#16182C] text-slate-400 border border-[#232644] uppercase font-bold">
                      {proj.status}
                    </span>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-2.5 text-rose-300">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-snug">
                  <strong>Peringatan:</strong> Seluruh naskah, breakdown adegan, subdivisi shot, prompt visual, dan riwayat pipeline untuk proyek-proyek ini akan dihapus secara permanen.
                </p>
              </div>

              {isBulkDeleting && (
                <div className="space-y-1.5 pt-2">
                  <div className="flex justify-between text-[11px] font-mono font-bold text-slate-300">
                    <span>Proses Menghapus...</span>
                    <span className="text-rose-400">{bulkProgress.current} / {bulkProgress.total}</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-[#1A1C2C] overflow-hidden border border-[#2B2D44]">
                    <div
                      className="h-full bg-rose-500 transition-all duration-200"
                      style={{ width: `${(bulkProgress.current / bulkProgress.total) * 100}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#23253A]">
              <button
                type="button"
                disabled={isBulkDeleting}
                onClick={() => setIsBulkDeleteModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-[#1C1E30] hover:bg-[#25283E] text-slate-300 text-xs font-bold transition cursor-pointer disabled:opacity-50"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isBulkDeleting}
                onClick={handleBulkDelete}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-rose-600/30 cursor-pointer disabled:opacity-50"
              >
                {isBulkDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus ({bulkProgress.current}/{bulkProgress.total})...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Ya, Hapus Semua ({filteredProjects.length} Proyek)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal Overlay */}
      {projectToDelete && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
          <div className="bg-[#181926] border border-rose-500/30 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2 rounded-xl bg-rose-500/15 border border-rose-500/30">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white">Hapus Proyek?</h4>
                <p className="text-xs text-slate-400">Tindakan ini tidak dapat dibatalkan.</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-[#212335] p-3.5 rounded-2xl border border-[#2B2D44]">
              Anda yakin ingin menghapus proyek{' '}
              <strong className="text-white font-bold">"{projectToDelete.title}"</strong>?
              Seluruh data cerita, karakter, lokasi, adegan, shot, dan prompt terkait akan dihapus secara permanen.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setProjectToDelete(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-[#212335] hover:bg-[#282B42] border border-[#2B2D44] transition disabled:opacity-50"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleDeleteConfirm}
                className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 shadow-lg shadow-rose-600/30 transition flex items-center gap-2 disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus Proyek</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Project Modal Overlay */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-[#181926] border border-[#2B2D44] rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative p-6 sm:p-8">
            <button
              onClick={() => setShowCreateForm(false)}
              className="absolute top-6 right-6 p-2 text-slate-400 hover:text-white bg-[#212335] hover:bg-[#282B42] rounded-2xl border border-[#2F324D] transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-6">
              <span className="text-[10px] font-mono uppercase font-bold text-indigo-400">
                PROSES INISIALISASI NASKAH
              </span>
              <h2 className="text-2xl font-black text-white mt-1">Buat Proyek Sinematik Baru</h2>
              <p className="text-xs text-slate-400 mt-1">
                Masukkan naskah film atau ide sinematik Anda. Agent AI akan membagi cerita ke dalam 8 tahapan otomatis.
              </p>
            </div>

            <NewProjectForm
              onSubmit={async (data) => {
                await onCreateProject(data);
                setShowCreateForm(false);
              }}
              isLoading={isCreating}
            />
          </div>
        </div>
      )}
    </div>
  );
};
